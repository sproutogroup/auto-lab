--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.appointments (
    id integer NOT NULL,
    customer_id integer,
    lead_id integer,
    vehicle_id integer,
    assigned_to_id integer NOT NULL,
    appointment_date timestamp without time zone NOT NULL,
    appointment_type text NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    appointment_time text NOT NULL,
    customer_name text,
    customer_phone text,
    customer_email text,
    duration_minutes integer DEFAULT 60
);


ALTER TABLE public.appointments OWNER TO neondb_owner;

--
-- Name: appointments_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.appointments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.appointments_id_seq OWNER TO neondb_owner;

--
-- Name: appointments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.appointments_id_seq OWNED BY public.appointments.id;


--
-- Name: bought_vehicles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.bought_vehicles (
    id integer NOT NULL,
    stock_number text NOT NULL,
    make text NOT NULL,
    model text NOT NULL,
    derivative text,
    colour text,
    mileage integer,
    year integer,
    registration text,
    location text,
    due_in timestamp without time zone,
    retail_price_1 numeric(10,2),
    retail_price_2 numeric(10,2),
    things_to_do text,
    vehicle_images text[],
    status text DEFAULT 'AWAITING'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.bought_vehicles OWNER TO neondb_owner;

--
-- Name: bought_vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.bought_vehicles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bought_vehicles_id_seq OWNER TO neondb_owner;

--
-- Name: bought_vehicles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.bought_vehicles_id_seq OWNED BY public.bought_vehicles.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text,
    phone text,
    address text,
    city text,
    postcode text,
    date_of_birth timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    mobile text,
    customer_status text DEFAULT 'prospect'::text NOT NULL,
    lead_source text,
    assigned_salesperson_id integer,
    total_purchases integer DEFAULT 0,
    total_spent numeric(10,2) DEFAULT 0.00,
    last_contact_date timestamp without time zone,
    next_follow_up_date timestamp without time zone,
    notes text,
    tags text[],
    preferred_contact_method text DEFAULT 'phone'::text,
    marketing_opt_in boolean DEFAULT false,
    gdpr_consent boolean DEFAULT false,
    title text,
    address_line_2 text,
    county text,
    email_opt_in boolean DEFAULT false,
    phone_opt_in boolean DEFAULT false,
    gdpr_consent_date timestamp without time zone,
    company_name text,
    vat_number text,
    trade_discount numeric(5,2) DEFAULT 0.00,
    credit_rating text,
    finance_preference text,
    vehicle_interests text[],
    budget_min numeric(10,2),
    budget_max numeric(10,2),
    trade_in_vehicle text
);


ALTER TABLE public.customers OWNER TO neondb_owner;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO neondb_owner;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: interactions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.interactions (
    id integer NOT NULL,
    lead_id integer,
    customer_id integer,
    vehicle_id integer,
    user_id integer NOT NULL,
    interaction_type text NOT NULL,
    interaction_direction text NOT NULL,
    interaction_outcome text,
    interaction_subject text,
    interaction_notes text NOT NULL,
    follow_up_required boolean DEFAULT false,
    follow_up_date timestamp without time zone,
    follow_up_priority text DEFAULT 'medium'::text,
    follow_up_notes text,
    duration_minutes integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.interactions OWNER TO neondb_owner;

--
-- Name: interactions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.interactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.interactions_id_seq OWNER TO neondb_owner;

--
-- Name: interactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.interactions_id_seq OWNED BY public.interactions.id;


--
-- Name: job_progress; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.job_progress (
    id integer NOT NULL,
    job_id integer NOT NULL,
    progress_stage text NOT NULL,
    stage_status text NOT NULL,
    user_id integer NOT NULL,
    stage_start_time timestamp without time zone DEFAULT now(),
    stage_end_time timestamp without time zone,
    duration_minutes integer,
    location_latitude numeric(10,8),
    location_longitude numeric(11,8),
    progress_notes text,
    issues_encountered text,
    photos_uploaded text[],
    signature_required boolean DEFAULT false,
    signature_captured boolean DEFAULT false,
    signature_name text,
    signature_data text,
    next_stage text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.job_progress OWNER TO neondb_owner;

--
-- Name: job_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.job_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.job_progress_id_seq OWNER TO neondb_owner;

--
-- Name: job_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.job_progress_id_seq OWNED BY public.job_progress.id;


--
-- Name: job_templates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.job_templates (
    id integer NOT NULL,
    template_name text NOT NULL,
    template_category text NOT NULL,
    job_type text NOT NULL,
    estimated_duration_hours numeric(5,2),
    default_priority text DEFAULT 'medium'::text,
    required_skills text[],
    required_equipment text[],
    checklist_items jsonb,
    instructions text,
    quality_checks jsonb,
    is_active boolean DEFAULT true,
    created_by_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.job_templates OWNER TO neondb_owner;

--
-- Name: job_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.job_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.job_templates_id_seq OWNER TO neondb_owner;

--
-- Name: job_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.job_templates_id_seq OWNED BY public.job_templates.id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.jobs (
    id integer NOT NULL,
    job_number text NOT NULL,
    job_type text NOT NULL,
    job_category text NOT NULL,
    job_priority text DEFAULT 'medium'::text NOT NULL,
    job_status text DEFAULT 'pending'::text NOT NULL,
    vehicle_id integer,
    customer_id integer,
    lead_id integer,
    assigned_to_id integer,
    created_by_id integer NOT NULL,
    supervisor_id integer,
    scheduled_date timestamp without time zone,
    actual_start_date timestamp without time zone,
    actual_end_date timestamp without time zone,
    estimated_duration_hours numeric(5,2),
    actual_duration_hours numeric(5,2),
    address_line_1 text,
    address_line_2 text,
    postcode text,
    contact_name text,
    contact_phone text,
    notes text,
    equipment_required text[],
    skills_required text[],
    estimated_cost numeric(10,2),
    actual_cost numeric(10,2),
    hourly_rate numeric(10,2),
    material_costs numeric(10,2),
    external_costs numeric(10,2),
    total_cost numeric(10,2),
    quality_check_required boolean DEFAULT false,
    quality_check_completed boolean DEFAULT false,
    quality_check_by_id integer,
    quality_rating integer,
    customer_satisfaction_rating integer,
    completion_notes text,
    issues_encountered text,
    photos_taken text[],
    documents_generated text[],
    parent_job_id integer,
    recurring_job_id integer,
    external_reference text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    city text,
    county text
);


ALTER TABLE public.jobs OWNER TO neondb_owner;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO neondb_owner;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: leads; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.leads (
    id integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    email text,
    primary_phone text,
    secondary_phone text,
    assigned_vehicle_id integer,
    vehicle_interests text,
    budget_min numeric(10,2),
    budget_max numeric(10,2),
    finance_required boolean DEFAULT false,
    trade_in_vehicle text,
    trade_in_value numeric(10,2),
    lead_source text NOT NULL,
    pipeline_stage text DEFAULT 'new'::text NOT NULL,
    lead_quality text DEFAULT 'unqualified'::text,
    priority text DEFAULT 'medium'::text,
    assigned_salesperson_id integer,
    converted_customer_id integer,
    lost_reason text,
    last_contact_date timestamp without time zone,
    next_follow_up_date timestamp without time zone,
    contact_attempts integer DEFAULT 0,
    notes text,
    internal_notes text,
    marketing_consent boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    part_exchange_registration text,
    part_exchange_mileage text,
    part_exchange_damage text,
    part_exchange_colour text,
    finance_preference_type text
);


ALTER TABLE public.leads OWNER TO neondb_owner;

--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.leads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.leads_id_seq OWNER TO neondb_owner;

--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.leads_id_seq OWNED BY public.leads.id;


--
-- Name: page_definitions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.page_definitions (
    id integer NOT NULL,
    page_key text NOT NULL,
    page_name text NOT NULL,
    page_description text,
    page_category text NOT NULL,
    is_system_page boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.page_definitions OWNER TO neondb_owner;

--
-- Name: page_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.page_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.page_definitions_id_seq OWNER TO neondb_owner;

--
-- Name: page_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.page_definitions_id_seq OWNED BY public.page_definitions.id;


--
-- Name: purchase_invoices; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.purchase_invoices (
    id integer NOT NULL,
    buyer_name text NOT NULL,
    description text,
    registration text,
    purchase_date timestamp without time zone,
    make text,
    model text,
    seller_type text,
    estimated_collection_date timestamp without time zone,
    outstanding_finance boolean DEFAULT false,
    part_exchange boolean DEFAULT false,
    document_filename text NOT NULL,
    document_path text NOT NULL,
    document_size integer,
    document_type text NOT NULL,
    upload_date timestamp without time zone DEFAULT now(),
    tags text[],
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.purchase_invoices OWNER TO neondb_owner;

--
-- Name: purchase_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.purchase_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_invoices_id_seq OWNER TO neondb_owner;

--
-- Name: purchase_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.purchase_invoices_id_seq OWNED BY public.purchase_invoices.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.purchases (
    id integer NOT NULL,
    vehicle_id integer NOT NULL,
    supplier_id integer,
    purchase_price numeric(10,2) NOT NULL,
    is_part_exchange boolean DEFAULT false,
    purchase_date timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.purchases OWNER TO neondb_owner;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchases_id_seq OWNER TO neondb_owner;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    vehicle_id integer NOT NULL,
    customer_id integer NOT NULL,
    salesperson_id integer NOT NULL,
    sale_price numeric(10,2) NOT NULL,
    gross_profit numeric(10,2),
    finance_amount numeric(10,2),
    finance_provider text,
    add_on_products jsonb,
    sale_date timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sales OWNER TO neondb_owner;

--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_id_seq OWNER TO neondb_owner;

--
-- Name: sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.sales_id_seq OWNED BY public.sales.id;


--
-- Name: sales_invoices; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sales_invoices (
    id integer NOT NULL,
    seller_name text NOT NULL,
    registration text,
    date_of_sale timestamp without time zone,
    delivery_collection text,
    make text,
    model text,
    customer_name text NOT NULL,
    notes text,
    paid_in_full boolean DEFAULT false,
    finance boolean DEFAULT false,
    part_exchange boolean DEFAULT false,
    documents_to_sign boolean DEFAULT false,
    document_filename text NOT NULL,
    document_path text NOT NULL,
    document_size integer,
    document_type text NOT NULL,
    upload_date timestamp without time zone DEFAULT now(),
    tags text[],
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sales_invoices OWNER TO neondb_owner;

--
-- Name: sales_invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.sales_invoices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_invoices_id_seq OWNER TO neondb_owner;

--
-- Name: sales_invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.sales_invoices_id_seq OWNED BY public.sales_invoices.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO neondb_owner;

--
-- Name: staff_schedules; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.staff_schedules (
    id integer NOT NULL,
    user_id integer NOT NULL,
    schedule_date timestamp without time zone NOT NULL,
    schedule_type text NOT NULL,
    shift_start_time text,
    shift_end_time text,
    break_duration_minutes integer DEFAULT 60,
    location text,
    availability_status text DEFAULT 'available'::text NOT NULL,
    notes text,
    is_recurring boolean DEFAULT false,
    recurring_pattern text,
    recurring_end_date timestamp without time zone,
    created_by_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.staff_schedules OWNER TO neondb_owner;

--
-- Name: staff_schedules_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.staff_schedules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.staff_schedules_id_seq OWNER TO neondb_owner;

--
-- Name: staff_schedules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.staff_schedules_id_seq OWNED BY public.staff_schedules.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    assigned_to_id integer NOT NULL,
    created_by_id integer NOT NULL,
    due_date timestamp without time zone,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tasks OWNER TO neondb_owner;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO neondb_owner;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    page_key text NOT NULL,
    permission_level text NOT NULL,
    can_create boolean DEFAULT false NOT NULL,
    can_edit boolean DEFAULT false NOT NULL,
    can_delete boolean DEFAULT false NOT NULL,
    can_export boolean DEFAULT false NOT NULL,
    custom_restrictions jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_permissions OWNER TO neondb_owner;

--
-- Name: user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_permissions_id_seq OWNER TO neondb_owner;

--
-- Name: user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.user_permissions_id_seq OWNED BY public.user_permissions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    email text,
    first_name text,
    last_name text,
    profile_image_url text,
    role text DEFAULT 'salesperson'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    password text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login timestamp without time zone
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO neondb_owner;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehicle_logistics; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.vehicle_logistics (
    id integer NOT NULL,
    vehicle_id integer NOT NULL,
    logistics_status text DEFAULT 'pending'::text NOT NULL,
    current_location text,
    current_location_address text,
    destination_location text,
    destination_address text,
    transport_method text,
    transport_company text,
    transport_reference text,
    driver_name text,
    driver_phone text,
    keys_location text,
    fuel_level text,
    condition_on_arrival text,
    condition_on_departure text,
    mileage_on_arrival integer,
    mileage_on_departure integer,
    service_book_present boolean DEFAULT false,
    spare_keys_count integer DEFAULT 0,
    v5_document_present boolean DEFAULT false,
    mot_certificate_present boolean DEFAULT false,
    insurance_documents_present boolean DEFAULT false,
    logistics_notes text,
    photos_on_arrival text[],
    photos_on_departure text[],
    assigned_to_id integer,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.vehicle_logistics OWNER TO neondb_owner;

--
-- Name: vehicle_logistics_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.vehicle_logistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicle_logistics_id_seq OWNER TO neondb_owner;

--
-- Name: vehicle_logistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.vehicle_logistics_id_seq OWNED BY public.vehicle_logistics.id;


--
-- Name: vehicle_makes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.vehicle_makes (
    id integer NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.vehicle_makes OWNER TO neondb_owner;

--
-- Name: vehicle_makes_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.vehicle_makes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicle_makes_id_seq OWNER TO neondb_owner;

--
-- Name: vehicle_makes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.vehicle_makes_id_seq OWNED BY public.vehicle_makes.id;


--
-- Name: vehicle_models; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.vehicle_models (
    id integer NOT NULL,
    make_id integer NOT NULL,
    name text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.vehicle_models OWNER TO neondb_owner;

--
-- Name: vehicle_models_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.vehicle_models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicle_models_id_seq OWNER TO neondb_owner;

--
-- Name: vehicle_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.vehicle_models_id_seq OWNED BY public.vehicle_models.id;


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.vehicles (
    id integer NOT NULL,
    stock_number text,
    department text,
    buyer text,
    sales_status text,
    collection_status text,
    registration text,
    make text,
    model text,
    derivative text,
    colour text,
    mileage integer,
    year integer,
    date_of_registration timestamp without time zone,
    chassis_number text,
    purchase_invoice_date timestamp without time zone,
    purchase_px_value numeric(10,2),
    purchase_cash numeric(10,2),
    purchase_fees numeric(10,2),
    purchase_finance_settlement numeric(10,2),
    purchase_bank_transfer numeric(10,2),
    vat numeric(10,2),
    purchase_price_total numeric(10,2),
    sale_date timestamp without time zone,
    bank_payment numeric(10,2),
    finance_payment numeric(10,2),
    finance_settlement numeric(10,2),
    px_value numeric(10,2),
    vat_payment numeric(10,2),
    cash_payment numeric(10,2),
    total_sale_price numeric(10,2),
    cash_o_b numeric(10,2),
    px_o_r_value numeric(10,2),
    road_tax numeric(10,2),
    dvla numeric(10,2),
    alloy_insurance numeric(10,2),
    paint_insurance numeric(10,2),
    gap_insurance numeric(10,2),
    parts_cost numeric(10,2),
    paint_labour_costs numeric(10,2),
    warranty_costs numeric(10,2),
    total_gp numeric(10,2),
    adj_gp numeric(10,2),
    payment_notes text,
    customer_first_name text,
    customer_surname text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.vehicles OWNER TO neondb_owner;

--
-- Name: vehicles_id_seq; Type: SEQUENCE; Schema: public; Owner: neondb_owner
--

CREATE SEQUENCE public.vehicles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicles_id_seq OWNER TO neondb_owner;

--
-- Name: vehicles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: neondb_owner
--

ALTER SEQUENCE public.vehicles_id_seq OWNED BY public.vehicles.id;


--
-- Name: appointments id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointments ALTER COLUMN id SET DEFAULT nextval('public.appointments_id_seq'::regclass);


--
-- Name: bought_vehicles id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bought_vehicles ALTER COLUMN id SET DEFAULT nextval('public.bought_vehicles_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: interactions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.interactions ALTER COLUMN id SET DEFAULT nextval('public.interactions_id_seq'::regclass);


--
-- Name: job_progress id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.job_progress ALTER COLUMN id SET DEFAULT nextval('public.job_progress_id_seq'::regclass);


--
-- Name: job_templates id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.job_templates ALTER COLUMN id SET DEFAULT nextval('public.job_templates_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads ALTER COLUMN id SET DEFAULT nextval('public.leads_id_seq'::regclass);


--
-- Name: page_definitions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.page_definitions ALTER COLUMN id SET DEFAULT nextval('public.page_definitions_id_seq'::regclass);


--
-- Name: purchase_invoices id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_invoices ALTER COLUMN id SET DEFAULT nextval('public.purchase_invoices_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: sales id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales ALTER COLUMN id SET DEFAULT nextval('public.sales_id_seq'::regclass);


--
-- Name: sales_invoices id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales_invoices ALTER COLUMN id SET DEFAULT nextval('public.sales_invoices_id_seq'::regclass);


--
-- Name: staff_schedules id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.staff_schedules ALTER COLUMN id SET DEFAULT nextval('public.staff_schedules_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: user_permissions id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_permissions ALTER COLUMN id SET DEFAULT nextval('public.user_permissions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vehicle_logistics id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_logistics ALTER COLUMN id SET DEFAULT nextval('public.vehicle_logistics_id_seq'::regclass);


--
-- Name: vehicle_makes id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_makes ALTER COLUMN id SET DEFAULT nextval('public.vehicle_makes_id_seq'::regclass);


--
-- Name: vehicle_models id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_models ALTER COLUMN id SET DEFAULT nextval('public.vehicle_models_id_seq'::regclass);


--
-- Name: vehicles id; Type: DEFAULT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicles ALTER COLUMN id SET DEFAULT nextval('public.vehicles_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.appointments (id, customer_id, lead_id, vehicle_id, assigned_to_id, appointment_date, appointment_type, status, notes, created_at, updated_at, appointment_time, customer_name, customer_phone, customer_email, duration_minutes) FROM stdin;
1	\N	\N	\N	1	2025-06-27 00:00:00	viewing	scheduled	Test appointment	2025-06-27 10:49:11.35783	2025-06-27 10:49:11.35783	14:30	Test Customer	123-456-7890	test@example.com	30
4	\N	\N	206	1	2025-06-26 00:00:00	viewing	scheduled		2025-06-27 11:11:48.070767	2025-06-27 11:11:48.070767	15:00	John	N/A		60
5	\N	\N	\N	1	2025-06-28 00:00:00	viewing	scheduled	Testing date display fix	2025-06-27 11:13:17.165232	2025-06-27 11:13:17.165232	11:00	Date Test Customer	123-456-7890	datetest@example.com	60
6	\N	\N	\N	1	2025-06-27 00:00:00	viewing	scheduled	Coming to see sports\n	2025-06-27 11:14:18.099658	2025-06-27 11:14:18.099658	12:00	Test			60
8	\N	\N	\N	1	2025-06-30 00:00:00	viewing	scheduled		2025-06-27 11:33:01.841033	2025-06-27 11:33:01.841033	09:00	Menaz Sulaman	07739537224	menaz@sulaman.com	60
2	\N	\N	206	1	2025-06-26 00:00:00	drop_off	scheduled	Test appointment	2025-06-27 11:08:35.724883	2025-06-27 11:08:35.724883	15:00				30
3	\N	\N	\N	1	2025-06-27 00:00:00	viewing	scheduled	Test appointment with proper customer data	2025-06-27 11:10:27.057164	2025-06-27 11:10:27.057164	16:00	Rizwan Sulaiman	123-456-7890	rizwan@autolab.com	30
7	\N	\N	211	1	2025-06-29 00:00:00	viewing	scheduled	Vehicle viewing appointment with comprehensive details for testing the new view modal functionality	2025-06-27 11:17:33.571951	2025-06-27 11:17:33.571951	10:00	Rizwan Sulaiman	07123456789	rizwan@autolab.com	60
\.


--
-- Data for Name: bought_vehicles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.bought_vehicles (id, stock_number, make, model, derivative, colour, mileage, year, registration, location, due_in, retail_price_1, retail_price_2, things_to_do, vehicle_images, status, created_at, updated_at) FROM stdin;
1	TEST12345	Mercedes Benz	C Class	C 43 PREMIUM + 4MATIC	White	53000	2019	R121 SUL	Test Location	2025-07-11 23:00:00	28000.00	29000.00	Refrub wheels	{https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?w=800&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?w=800&auto=format&fit=crop&q=60,https://images.unsplash.com/photo-1607853554439-0069ec0f29b6?w=800&auto=format&fit=crop&q=60}	AWAITING	2025-07-07 09:33:42.000376	2025-07-07 09:52:36.81
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.customers (id, first_name, last_name, email, phone, address, city, postcode, date_of_birth, created_at, updated_at, mobile, customer_status, lead_source, assigned_salesperson_id, total_purchases, total_spent, last_contact_date, next_follow_up_date, notes, tags, preferred_contact_method, marketing_opt_in, gdpr_consent, title, address_line_2, county, email_opt_in, phone_opt_in, gdpr_consent_date, company_name, vat_number, trade_discount, credit_rating, finance_preference, vehicle_interests, budget_min, budget_max, trade_in_vehicle) FROM stdin;
\.


--
-- Data for Name: interactions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.interactions (id, lead_id, customer_id, vehicle_id, user_id, interaction_type, interaction_direction, interaction_outcome, interaction_subject, interaction_notes, follow_up_required, follow_up_date, follow_up_priority, follow_up_notes, duration_minutes, created_at, updated_at) FROM stdin;
6	\N	\N	\N	1	phone_call	inbound			test\n	f	\N	medium		\N	2025-06-27 09:59:43.985081	2025-06-27 09:59:43.985081
7	4	\N	\N	2	email	inbound	neutral	2025-07-02	test	t	2025-07-05 00:00:00	medium	test\n	\N	2025-07-03 11:07:51.448666	2025-07-03 11:07:51.448666
8	4	\N	\N	2	phone_call	outbound	positive	2025-07-04	Test interaction	f	\N	medium	\N	15	2025-07-04 09:33:55.613508	2025-07-04 09:33:55.613508
9	4	\N	\N	1	phone_call	inbound	positive	2025-07-03	test	f	\N	medium	\N	\N	2025-07-04 09:53:54.409398	2025-07-04 09:53:54.409398
10	4	\N	\N	1	email	inbound	neutral	2025-07-04	test reply	t	2025-07-10 00:00:00	high	test 3	\N	2025-07-04 09:54:23.23494	2025-07-04 09:54:23.23494
11	4	\N	\N	1	email	outbound	positive	2025-07-03	test	f	\N	medium	\N	\N	2025-07-04 10:00:54.463298	2025-07-04 10:00:54.463298
12	4	\N	\N	1	in_person	inbound	neutral	2025-07-03	test 4	f	\N	medium	\N	\N	2025-07-04 10:12:50.452918	2025-07-04 10:12:50.452918
13	4	\N	\N	2	finance_discussion	inbound	neutral	2025-07-03	Quotes given - test 	f	\N	medium	\N	\N	2025-07-04 10:21:48.792183	2025-07-04 10:21:48.792183
14	4	\N	\N	2	objection_handling	inbound	callback_requested	2025-07-12	test 4	f	\N	medium	\N	\N	2025-07-04 10:24:20.296493	2025-07-04 10:24:20.296493
\.


--
-- Data for Name: job_progress; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.job_progress (id, job_id, progress_stage, stage_status, user_id, stage_start_time, stage_end_time, duration_minutes, location_latitude, location_longitude, progress_notes, issues_encountered, photos_uploaded, signature_required, signature_captured, signature_name, signature_data, next_stage, created_at) FROM stdin;
\.


--
-- Data for Name: job_templates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.job_templates (id, template_name, template_category, job_type, estimated_duration_hours, default_priority, required_skills, required_equipment, checklist_items, instructions, quality_checks, is_active, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.jobs (id, job_number, job_type, job_category, job_priority, job_status, vehicle_id, customer_id, lead_id, assigned_to_id, created_by_id, supervisor_id, scheduled_date, actual_start_date, actual_end_date, estimated_duration_hours, actual_duration_hours, address_line_1, address_line_2, postcode, contact_name, contact_phone, notes, equipment_required, skills_required, estimated_cost, actual_cost, hourly_rate, material_costs, external_costs, total_cost, quality_check_required, quality_check_completed, quality_check_by_id, quality_rating, customer_satisfaction_rating, completion_notes, issues_encountered, photos_taken, documents_generated, parent_job_id, recurring_job_id, external_reference, created_at, updated_at, city, county) FROM stdin;
2	DEL-903621	delivery	logistics	medium	completed	206	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	34 Barker Lane		bb1 3aq	\N	\N		\N	\N	-24.00	\N	\N	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-06-27 14:01:43.788913	2025-07-03 08:12:45.531	London	
1	DEL-555285	delivery	logistics	medium	failed	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	123 Test Street	\N	SW1A 1AA	\N	\N	Test job creation	\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-06-27 13:55:55.45816	2025-07-03 08:20:45.546	London	\N
7	COL-316715	collection	logistics	medium	completed	180	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	123 High Street			Kai	0987654321		\N	\N	500.00	700.00	\N	\N	\N	\N	t	f	\N	\N	\N			\N	\N	\N	\N		2025-07-03 08:28:36.87238	2025-07-03 08:33:49.576		
6	DEL-148773	delivery	logistics	medium	failed	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	500.00	700.00	\N	\N	\N	18.00	f	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2025-07-03 08:25:51.601783	2025-07-03 08:35:53.223	\N	\N
8	DEL-787718	delivery	logistics	medium	completed	180	\N	\N	1	1	\N	\N	\N	\N	\N	\N				Kai	0987654321		\N	\N	\N	\N	\N	\N	\N	\N	t	f	\N	\N	\N			\N	\N	\N	\N	ABC123	2025-07-07 11:13:07.89487	2025-07-07 11:18:54.345		
9	MOT-296437	mot	logistics	low	completed	175	\N	\N	\N	1	\N	\N	\N	\N	\N	\N				Kai	1234567890		\N	\N	120.00	150.00	\N	\N	\N	\N	f	f	\N	\N	\N			\N	\N	\N	\N		2025-07-07 11:21:36.61656	2025-07-07 11:21:41.536		
10	MOT-873367	mot	logistics	low	completed	180	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	123 High Street			Kai	1234567890		\N	\N	\N	\N	\N	\N	\N	\N	f	f	\N	\N	\N			\N	\N	\N	\N		2025-07-07 11:31:13.840566	2025-07-07 11:46:00.654		
11	INS-957689	inspection	logistics	medium	completed	180	\N	\N	\N	1	\N	\N	\N	\N	\N	\N				Peter			\N	\N	100.00	\N	\N	\N	\N	\N	f	f	\N	\N	\N			\N	\N	\N	\N		2025-07-07 12:05:57.871952	2025-07-07 14:04:14.444		
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.leads (id, first_name, last_name, email, primary_phone, secondary_phone, assigned_vehicle_id, vehicle_interests, budget_min, budget_max, finance_required, trade_in_vehicle, trade_in_value, lead_source, pipeline_stage, lead_quality, priority, assigned_salesperson_id, converted_customer_id, lost_reason, last_contact_date, next_follow_up_date, contact_attempts, notes, internal_notes, marketing_consent, created_at, updated_at, part_exchange_registration, part_exchange_mileage, part_exchange_damage, part_exchange_colour, finance_preference_type) FROM stdin;
4	Rizwan	Sulaman	riz@autolabuk.com	07809480103		248		NaN	50000.00	f		NaN	AutoTrader	new	unqualified	medium	\N	\N		\N	\N	0			f	2025-07-03 09:32:35.178606	2025-07-04 10:24:20.124	R121 SUL	54000	Excellent	White	Combination
\.


--
-- Data for Name: page_definitions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.page_definitions (id, page_key, page_name, page_description, page_category, is_system_page, created_at, updated_at) FROM stdin;
15	dashboard	Dashboard	Main dashboard with overview and analytics	overview	t	2025-07-08 11:12:16.479561	2025-07-08 11:12:16.479561
16	vehicle-master	Vehicle Master	Complete vehicle inventory management	vehicles	f	2025-07-08 11:12:16.534512	2025-07-08 11:12:16.534512
17	sold-stock	Sold Stock	View sold vehicle inventory	vehicles	f	2025-07-08 11:12:16.579828	2025-07-08 11:12:16.579828
18	current-stock	Current Stock	View current vehicle stock	vehicles	f	2025-07-08 11:12:16.62632	2025-07-08 11:12:16.62632
19	stock-age	Stock Age	Stock age analysis and reporting	vehicles	f	2025-07-08 11:12:16.67243	2025-07-08 11:12:16.67243
20	bought-vehicles	Bought Vehicles	Manage newly purchased vehicles	vehicles	f	2025-07-08 11:12:16.716901	2025-07-08 11:12:16.716901
21	customers	Customers	Manage customer relationships and data	sales	f	2025-07-08 11:12:16.762251	2025-07-08 11:12:16.762251
22	leads	Leads	Manage sales leads and prospects	sales	f	2025-07-08 11:12:16.807307	2025-07-08 11:12:16.807307
23	appointments	Appointments	Schedule and manage appointments	sales	f	2025-07-08 11:12:16.85333	2025-07-08 11:12:16.85333
24	tasks	Tasks	Task management and tracking	sales	f	2025-07-08 11:12:16.898667	2025-07-08 11:12:16.898667
25	purchase-invoices	Purchase Invoices	Manage purchase invoice documents	documents	f	2025-07-08 11:12:16.943654	2025-07-08 11:12:16.943654
26	sales-invoices	Sales Invoices	Manage sales invoice documents	documents	f	2025-07-08 11:12:16.988924	2025-07-08 11:12:16.988924
27	collection-forms	Collection Forms	Vehicle collection forms and documentation	documents	f	2025-07-08 11:12:17.034656	2025-07-08 11:12:17.034656
28	pdf-templates	PDF Templates	Document templates and generation	documents	f	2025-07-08 11:12:17.080326	2025-07-08 11:12:17.080326
29	calendar	Calendar	Calendar view and scheduling	management	f	2025-07-08 11:12:17.12555	2025-07-08 11:12:17.12555
30	schedule	Schedule	View and manage work schedules	management	f	2025-07-08 11:12:17.171715	2025-07-08 11:12:17.171715
31	job-history	Job History	View completed job history	management	f	2025-07-08 11:12:17.217563	2025-07-08 11:12:17.217563
32	reports	Reports	Business intelligence and analytics	analysis	f	2025-07-08 11:12:17.264065	2025-07-08 11:12:17.264065
33	users	Users	Manage system users and permissions	system	t	2025-07-08 11:12:17.308986	2025-07-08 11:12:17.308986
\.


--
-- Data for Name: purchase_invoices; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.purchase_invoices (id, buyer_name, description, registration, purchase_date, make, model, seller_type, estimated_collection_date, outstanding_finance, part_exchange, document_filename, document_path, document_size, document_type, upload_date, tags, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.purchases (id, vehicle_id, supplier_id, purchase_price, is_part_exchange, purchase_date, created_at) FROM stdin;
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sales (id, vehicle_id, customer_id, salesperson_id, sale_price, gross_profit, finance_amount, finance_provider, add_on_products, sale_date, created_at) FROM stdin;
\.


--
-- Data for Name: sales_invoices; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sales_invoices (id, seller_name, registration, date_of_sale, delivery_collection, make, model, customer_name, notes, paid_in_full, finance, part_exchange, documents_to_sign, document_filename, document_path, document_size, document_type, upload_date, tags, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sessions (sid, sess, expire) FROM stdin;
KesxEfw67-E1isEwLrSzrRUPRfJPh4Rz	{"user": {"id": 1, "role": "admin", "email": "admin@dealership.com", "username": "admin", "is_active": true, "last_name": "Admin", "created_at": "2025-06-27T09:58:44.746Z", "first_name": "System", "last_login": "2025-07-08T12:25:14.143Z", "updated_at": "2025-07-08T09:34:09.677Z", "profile_image_url": null}, "cookie": {"path": "/", "secure": false, "expires": "2025-07-09T12:25:14.143Z", "httpOnly": true, "sameSite": "lax", "originalMaxAge": 86400000}}	2025-07-09 12:25:15
\.


--
-- Data for Name: staff_schedules; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.staff_schedules (id, user_id, schedule_date, schedule_type, shift_start_time, shift_end_time, break_duration_minutes, location, availability_status, notes, is_recurring, recurring_pattern, recurring_end_date, created_by_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tasks (id, title, description, assigned_to_id, created_by_id, due_date, priority, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_permissions (id, user_id, page_key, permission_level, can_create, can_edit, can_delete, can_export, custom_restrictions, created_at, updated_at) FROM stdin;
5	4	bought-vehicles	hidden	f	f	f	f	\N	2025-07-08 11:12:30.266377	2025-07-08 11:15:36.51
7	4	sold-stock	full_access	f	f	f	f	\N	2025-07-08 11:22:08.416805	2025-07-08 11:22:08.416805
8	4	dashboard	full_access	t	t	t	t	\N	2025-07-08 11:45:50.467532	2025-07-08 11:45:50.467532
9	4	customers	view_only	f	f	f	f	\N	2025-07-08 11:45:50.467532	2025-07-08 11:45:50.467532
10	4	current-stock	view_only	f	f	f	f	\N	2025-07-08 11:45:50.467532	2025-07-08 12:07:39.554
6	4	vehicle-master	full_access	t	t	t	t	\N	2025-07-08 11:15:37.502971	2025-07-08 12:09:15.596
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, username, email, first_name, last_name, profile_image_url, role, created_at, updated_at, password, is_active, last_login) FROM stdin;
4	test	test@email.com	test	user	\N	salesperson	2025-07-08 11:04:50.850963	2025-07-08 11:04:50.850963	$2b$12$sE571dW7djGisKwflzjFHuMi4ga5XfM3JEjsw9YFMmHLWIu0cboeO	t	2025-07-08 12:13:06.871
1	admin	admin@dealership.com	System	Admin	\N	admin	2025-06-27 09:58:44.746405	2025-07-08 09:34:09.677969	$2b$12$v2uCDlS5a/KWPaYJtFabY.IUeaH3.TIF11LS2xZnhfm7e/qDdDIX.	t	2025-07-09 11:25:12.429
2	system	system@dealership.com	System	User	\N	admin	2025-07-03 10:04:02.814375	2025-07-03 10:04:02.814375	$2b$12$sE571dW7djGisKwflzjFHuMi4ga5XfM3JEjsw9YFMmHLWIu0cboeO	t	\N
\.


--
-- Data for Name: vehicle_logistics; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.vehicle_logistics (id, vehicle_id, logistics_status, current_location, current_location_address, destination_location, destination_address, transport_method, transport_company, transport_reference, driver_name, driver_phone, keys_location, fuel_level, condition_on_arrival, condition_on_departure, mileage_on_arrival, mileage_on_departure, service_book_present, spare_keys_count, v5_document_present, mot_certificate_present, insurance_documents_present, logistics_notes, photos_on_arrival, photos_on_departure, assigned_to_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicle_makes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.vehicle_makes (id, name, created_at) FROM stdin;
\.


--
-- Data for Name: vehicle_models; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.vehicle_models (id, make_id, name, created_at) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.vehicles (id, stock_number, department, buyer, sales_status, collection_status, registration, make, model, derivative, colour, mileage, year, date_of_registration, chassis_number, purchase_invoice_date, purchase_px_value, purchase_cash, purchase_fees, purchase_finance_settlement, purchase_bank_transfer, vat, purchase_price_total, sale_date, bank_payment, finance_payment, finance_settlement, px_value, vat_payment, cash_payment, total_sale_price, cash_o_b, px_o_r_value, road_tax, dvla, alloy_insurance, paint_insurance, gap_insurance, parts_cost, paint_labour_costs, warranty_costs, total_gp, adj_gp, payment_notes, customer_first_name, customer_surname, created_at, updated_at) FROM stdin;
20	AL243879	AL	PX	Sold	On Site	KP69 TXG (2)	Land Rover	Sport	HSE 7 STR	Grey	42000	2019	2019-09-18 23:00:00	SALWA2AK1LA892799	2024-11-28 00:00:00	26894.91	0.00	0.00	0.00	0.00	0.00	26894.91	2025-01-16 00:00:00	850.00	33175.00	0.00	0.00	0.00	0.00	34025.00	2850.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Daniel	Christopher	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
16	AL243884	AL	PX	Sold	On Site	SM72 GDX (2)	Land Rover	Vogue	D300 SE	Black	22000	2022	2022-11-30 00:00:00	SALKA9AW9PA037638	2024-12-02 00:00:00	70000.00	0.00	0.00	0.00	0.00	0.00	70000.00	2025-01-14 00:00:00	19000.00	52000.00	0.00	0.00	0.00	0.00	71000.00	6000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Shadab	Feroz	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
17	AL243803	AL	MS	Sold	On Site	LN24 XTO	Land Rover	Defender 110	XS EDTION	Black	8500	2024	2024-03-01 00:00:00	SALEA7AW6R2280418	2024-09-12 23:00:00	0.00	0.00	0.00	0.00	62000.00	0.00	62000.00	2025-01-15 00:00:00	71875.00	0.00	0.00	0.00	0.00	0.00	71875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Shaun	Hargreaves	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
21	AL253906	AL	MS	Sold	On Site	YY24 KCE	Land Rover	Defender 110	D250 XS EDT MHEV	Black	12000	2024	2024-04-21 23:00:00	SALEA7AW2R2319246	2025-01-10 00:00:00	0.00	0.00	0.00	0.00	61791.00	0.00	61791.00	2025-01-17 00:00:00	50000.00	20000.00	0.00	0.00	0.00	0.00	70000.00	0.00	0.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Brendan	Bardon	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
13	AL243828	AL	MS	Sold	On Site	EJ72 BSV (2)	Porsche	911	992 GTS 4S	White	14500	2022	2022-09-08 23:00:00	WP0ZZZ99ZNS215144	2024-10-19 23:00:00	98500.00	0.00	0.00	0.00	0.00	0.00	98500.00	2025-01-09 00:00:00	105000.00	0.00	0.00	0.00	0.00	0.00	105000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Emma	Turner	2025-06-26 08:09:24.223	2025-06-30 10:05:02.71
10	AL243836	AL	MS	Sold	On Site	SV73 LRA	Land Rover	Defender 110	D250 XS EDTION	Black	4000	2023	2023-10-23 23:00:00	SALEA7AW8R2269159	2024-10-24 23:00:00	0.00	0.00	0.00	0.00	59500.00	0.00	59500.00	2025-01-08 00:00:00	30500.00	0.00	0.00	38000.00	0.00	0.00	68500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	HLW	Farms	2025-06-26 08:09:24.223	2025-06-30 10:04:39.709
22	AL243868	AL	MS	Sold	On Site	BC70 UVP	Land Rover	Sport	ABIO DYN SDV6	Black	48000	2020	2020-09-15 23:00:00	SALWA2AK7LA737786	2024-11-20 00:00:00	0.00	0.00	0.00	0.00	34000.00	0.00	34000.00	2025-01-20 00:00:00	5000.00	36875.00	0.00	0.00	0.00	0.00	41875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Dylan	Oliver	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
23	AL243763	AL	ZH	Sold	On Site	MY16 MRS	Audi	Q7 S Line	Vorsprung TDI 50	Black	49280	2019	2019-09-19 23:00:00	WAUZZZ4M3KD032075	2024-07-25 23:00:00	0.00	0.00	0.00	35167.59	4553.41	0.00	39721.00	2025-01-24 00:00:00	41047.00	0.00	0.00	0.00	0.00	0.00	41047.00	0.00	0.00	190.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Richard	Rawlins	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
24	AL253901	AL	MS	Sold	On Site	YD71 CXK	Audi	Q5 S Line	EDT 1 TFSi	Nardo	24000	2021	2021-09-08 23:00:00	WAUZZZFY4M2122060	2025-01-06 00:00:00	0.00	0.00	0.00	0.00	31500.00	0.00	31500.00	2025-01-24 00:00:00	1500.00	33875.00	0.00	0.00	0.00	0.00	35375.00	500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Sarah	Downey	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
25	AL253903	AL	MS	Sold	On Site	SM74 ZGA	Land Rover	Defender 110	D250 X-DYN HSE	Black	250	2025	2025-01-08 00:00:00	SALEA7AW2S2380442	2025-01-08 00:00:00	0.00	0.00	0.00	0.00	74774.00	0.00	74774.00	2025-01-24 00:00:00	5000.00	79875.00	0.00	0.00	0.00	0.00	84875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	Real Purchase Price 74214 (RFL RFND)	Robert	Ellery	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
26	AL243870	AL	ZH	Sold	On Site	KE21 HPA	Mercedes	CLA 35	Prem Plus	Black	21500	2021	2021-07-01 23:00:00	W1K1186512N236302	2024-11-22 00:00:00	0.00	0.00	0.00	24590.16	4714.84	0.00	29305.00	2025-01-27 00:00:00	34275.00	0.00	0.00	0.00	0.00	0.00	34275.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Richard	Kenyon	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
27	AL243892	AL	PX	Sold	On Site	PN18 LMM	VW	Tiguan	R Line	White	78000	2018	2018-03-09 00:00:00	WVGZZZ5NZJW385033	2024-12-09 00:00:00	12000.00	0.00	0.00	0.00	0.00	0.00	12000.00	2025-01-27 00:00:00	8495.00	8000.00	0.00	0.00	0.00	0.00	16495.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Joesph	Jacques	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
7	AL253900	AL	MS	Sold	On Site	DP74 YJT	Land Rover	Defender 110	X-DYN HSE D250	Black	250	2024	2024-12-31 00:00:00	SALEA7AW6S2401194	2025-01-06 00:00:00	0.00	0.00	0.00	0.00	72990.00	0.00	72990.00	2025-01-06 00:00:00	84000.00	0.00	0.00	0.00	0.00	0.00	84000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Thomas	Ince	2025-06-26 08:09:24.223	2025-06-30 10:03:56.909
8	AL243832	AL	ZH	Sold	On Site	SC22 UXU	Audi	SQ7	Vorsprung  TFSI	Black	14500	2022	2022-05-30 23:00:00	WAUZZZ4M4ND020733	2024-10-21 23:00:00	0.00	0.00	0.00	0.00	64500.00	0.00	64500.00	2025-01-07 00:00:00	65375.00	0.00	0.00	0.00	0.00	0.00	65375.00	4000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Imran	\N	2025-06-26 08:09:24.223	2025-06-30 10:04:13.313
9	AL243863	AL	ZH	Sold	On Site	LJ23 XYU	Land Rover	Defender 110	D250 XS EDT	Black	10000	2024	2024-07-30 23:00:00	SALEA7AW3R2246078	2024-11-15 00:00:00	0.00	0.00	0.00	0.00	59000.00	0.00	59000.00	2025-01-07 00:00:00	7620.00	60255.00	0.00	0.00	0.00	0.00	67875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.223	2025-06-30 10:04:05.96
11	AL243846	AL	MS	Sold	On Site	SW24 GUU	Land Rover	Defender 110	D300 X-DYN SE	Eiger	7500	2024	2024-05-09 23:00:00	SALEA7AW8R2319557	2024-10-30 00:00:00	0.00	500.00	0.00	0.00	59500.00	0.00	60000.00	2025-01-08 00:00:00	68000.00	0.00	0.00	0.00	0.00	0.00	68000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.223	2025-06-30 10:04:33.349
12	AL243893	AL	ZH	Sold	On Site	RX73 ZHT	Land Rover	Sport	DYN SE D300	Borasco	11000	2023	2023-10-22 23:00:00	SAL1A2AW6RA163249	2024-12-13 00:00:00	68000.00	0.00	0.00	0.00	0.00	0.00	68000.00	2025-01-08 00:00:00	3500.00	0.00	0.00	75875.00	0.00	0.00	79375.00	5000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Rashad	Khan	2025-06-26 08:09:24.223	2025-06-30 10:04:26.325
14	AL243853	AL	PX	Sold	On Site	HX65 ONO	BMW	X5M	30D M Sport	Black	78000	2015	2015-08-31 23:00:00	WBSKT620800C89866	2024-11-05 00:00:00	22375.00	0.00	0.00	0.00	0.00	0.00	22375.00	2025-01-09 00:00:00	21000.00	0.00	0.00	0.00	0.00	0.00	21000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	JDT	Motors	2025-06-26 08:09:24.223	2025-06-30 10:04:48.384
15	AL243874	AL	MS	Sold	On Site	PL22 YCJ	Land Rover	Sport	HSE DYN BLK P400e	Black	25200	2022	2022-06-28 23:00:00	SALWA2AY5NA238914	2024-11-23 00:00:00	0.00	0.00	0.00	0.00	40750.00	0.00	40750.00	2025-01-10 00:00:00	47875.00	0.00	0.00	0.00	0.00	0.00	47875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Cummock	Surfacing	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
18	AL243867	AL	MS	Sold	On Site	GX23 ULF	Land Rover	Sport	DYN SE P440e	Grey	24500	2023	2023-04-26 23:00:00	SAL1A2A49PA131004	2024-11-19 00:00:00	0.00	0.00	0.00	0.00	58291.67	11658.33	69950.00	2025-01-15 00:00:00	66562.50	0.00	0.00	0.00	13312.50	0.00	79875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Christina	Lias	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
19	AL243875	AL	MS	Sold	On Site	WG74 LKL	VW	Amarok	Dcab PanAmerica V6	Blue	500	2024	2024-11-21 00:00:00	WV4ZZZT11RS019950	2024-11-25 00:00:00	0.00	0.00	0.00	0.00	46000.00	9200.00	55200.00	2025-01-16 00:00:00	55000.00	0.00	0.00	0.00	11000.00	0.00	66000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Sebalex	Cabling	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
6	AL243845	AL	ZH	Sold	On Site	SY70 WBW	Audi	Q7 S Line	55 TFSIe Hybrid	Black	39500	2020	2020-09-29 23:00:00	WAUZZZ4M3LD010434	2024-10-29 00:00:00	0.00	0.00	0.00	0.00	29000.00	0.00	29000.00	2025-01-04 00:00:00	37000.00	0.00	0.00	0.00	0.00	0.00	37000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.223	2025-06-30 10:03:49.634
33	AL253907	AL	MS	Sold	On Site	HN22 JTX	Land Rover	Defender 110	D250 X-DYN HSE	Grey	25209	2022	2022-03-25 00:00:00	SALEA7AWXP2108275	2025-01-10 00:00:00	0.00	0.00	0.00	0.00	58250.00	0.00	58250.00	2025-02-01 00:00:00	20000.00	47000.00	0.00	0.00	0.00	0.00	67000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Khalil	Hanif	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
34	AL253898	AL	MS	Sold	On Site	CX70 KVH	Land Rover	Sport	HSE SLVR EDT P400e	Black	17000	2020	2020-10-14 23:00:00	SALWA2AYXMA752255	2025-01-01 00:00:00	0.00	0.00	0.00	0.00	34500.00	0.00	34500.00	2025-02-03 00:00:00	31875.00	0.00	0.00	0.00	0.00	5600.00	37475.00	4000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	(Jordan) Tylor	Evans	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
35	AL253918	AL	PX	Sold	On Site	YH71 NDE	BMW	IiX E Drive	40 M Sport	White	23480	2021	2021-09-06 23:00:00	WBY12CF080CH68977	2025-01-16 00:00:00	33000.00	0.00	0.00	0.00	0.00	0.00	33000.00	2025-02-04 00:00:00	38875.00	0.00	0.00	0.00	0.00	0.00	38875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Chris	Errington	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
36	AL253928	AL	MS	Sold	On Site	HN23 UXX	Land Rover	Sport	DYN-SE D300 MHEV	Black	19300	2023	2023-04-11 23:00:00	SAL1A2AW0PA130406	2025-01-29 00:00:00	0.00	0.00	0.00	0.00	67300.00	0.00	67300.00	2025-02-05 00:00:00	25000.00	51000.00	0.00	0.00	0.00	0.00	76000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Gary	Millar	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
37	AL253929	AL	MS	Sold	On Site	KW74 FUG	VW	Amarok	Dcab PanAmerica V6	Black	250	2025	2025-01-28 00:00:00	WV4ZZZT11RS025330	2025-01-29 00:00:00	0.00	0.00	0.00	0.00	45000.00	9000.00	54000.00	2025-02-08 00:00:00	51896.67	0.00	0.00	0.00	10379.33	0.00	62276.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	J Oates	Engineering Ltd	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
38	AL243890	AL	MS	Sold	On Site	KP22 GVD	Land Rover	Sport	HSE DYN BLK P400e	Black	26000	2022	2022-03-10 00:00:00	SALWA2AY4NA235423	2024-12-09 00:00:00	0.00	0.00	0.00	33564.31	6435.69	0.00	40000.00	2025-02-10 00:00:00	1000.00	47875.00	0.00	0.00	0.00	0.00	48875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Samuel	Callander	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
39	AL243895	AL	ZH	Sold	On Site	CE70 HTX	Toyota	Landcruiser	Invincible 2.8D	Silver	48000	2020	2020-08-31 23:00:00	JTEBR3FJ30K163984	2024-12-17 00:00:00	0.00	0.00	0.00	0.00	38750.00	0.00	38750.00	2025-02-11 00:00:00	44375.00	0.00	0.00	0.00	0.00	0.00	44375.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Benjamin	Teale	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
40	AL243894	AL	PX	Sold	On Site	MV66 EDF	Mercedes	C43 Estate	Prem Plus	Blue	53100	2016	2016-09-13 23:00:00	WDD2052642F452605	2024-12-17 00:00:00	19000.00	0.00	0.00	0.00	0.00	0.00	19000.00	2025-02-13 00:00:00	23200.00	0.00	0.00	0.00	0.00	0.00	23200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Callum	Reid	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
41	AL243896	AL	PX	Sold	On Site	BU69 VMO	Land Rover	Sport	HST	Silver	35000	2019	2019-10-29 00:00:00	SALWA2AU0LA876630	2024-12-18 00:00:00	29000.00	0.00	0.00	0.00	0.00	0.00	29000.00	2025-02-14 00:00:00	26000.00	11145.00	0.00	0.00	0.00	0.00	37145.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Shadab	Nayeemuddin	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
42	AL253919	AL	MS	Sold	On Site	YK23 UZV	Land Rover	Defender 110	X-DYN HSE 7 STR	Carpathian	29600	2023	2023-03-17 00:00:00	SALEA7AW7P2193107	2025-01-17 00:00:00	0.00	0.00	0.00	64130.75	-2100.00	0.00	62030.75	2025-02-14 00:00:00	10000.00	61875.00	0.00	0.00	0.00	0.00	71875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	Tracker	Toni	Smith	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
43	AL253931	AL	PX	Sold	On Site	KR19 XEH	Land Rover	Sport	HE SDV6	Black	55000	2019	2019-03-27 00:00:00	SALWA2AK3KA857468	2025-02-03 00:00:00	26670.00	0.00	0.00	0.00	0.00	0.00	26670.00	2025-02-17 00:00:00	31875.00	0.00	0.00	0.00	0.00	0.00	31875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Sean	McGowen	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
44	AL253926	AL	FA	Sold	On Site	YC23 DWG (2)	Land Rover	Sport	P510e Autobiography	Eiger Grey	2800	2023	2023-03-25 00:00:00	SAL1A2A48PA128143	2025-01-28 00:00:00	0.00	0.00	0.00	0.00	82500.00	0.00	82500.00	2025-02-18 00:00:00	10000.00	90727.52	-38852.52	30000.00	0.00	0.00	91875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Scott	Campbell	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
45	AL243876	AL	MS	Sold	On Site	WG74 ZHO	VW	Amarok	Dcab PanAmerica V6	Red	500	2024	2024-11-25 00:00:00	WV4ZZZT10RS020314	2024-11-26 00:00:00	0.00	0.00	0.00	0.00	45000.00	9000.00	54000.00	2025-02-20 00:00:00	55000.00	0.00	0.00	0.00	11000.00	0.00	66000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Abdul	Toheed	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
46	AL253904	AL	MS	Sold	On Site	GX23 VTK	Land Rover	Vogue	SE P440e	Black	28500	2023	2023-06-05 23:00:00	SALKA9A43PA041974	2025-01-09 00:00:00	0.00	0.00	0.00	0.00	65000.00	13000.00	78000.00	2025-02-20 00:00:00	520.00	42291.67	0.00	31355.00	14833.33	0.00	89000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Andrew	Tebano	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
47	AL253910	AL	MS	Sold	On Site	NX71 OYN	Land Rover	Defender 110	D250 S MHEV	Black	36000	2025	2025-10-19 23:00:00	SALEA7AW5N2088000	2025-01-11 00:00:00	0.00	0.00	0.00	0.00	48500.00	0.00	48500.00	2025-02-20 00:00:00	58000.00	0.00	0.00	0.00	0.00	0.00	58000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Edward John	Shaw	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
48	AL243800	AL	PX	Sold	On Site	BJ68 CGU	Tesla	Model X	75D	Red	50000	2018	2018-09-25 23:00:00	5YJXDCE27JF114787	2024-09-08 23:00:00	21875.00	0.00	0.00	0.00	0.00	0.00	21875.00	2025-02-21 00:00:00	26975.00	0.00	0.00	0.00	0.00	0.00	26975.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Mark	Wilson	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
49	AL253934	AL	MS	Sold	On Site	SL74 EDX	VW	Amarok	Dcab PanAmerica V6	Grey	300	2025	2025-02-06 00:00:00	WV4ZZZT17RS027423	2025-02-08 00:00:00	0.00	0.00	0.00	0.00	45000.00	9000.00	54000.00	2025-02-21 00:00:00	26666.67	0.00	0.00	30000.00	11333.33	0.00	68000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	S Lyon	and Son Ltd	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
50	AL253935	AL	MS	Sold	On Site	SL74 EDU	VW	Amarok	Dcab PanAmerica V6	Grey	300	2025	2025-02-06 00:00:00	WV4ZZZT11RS027112	2025-02-08 00:00:00	0.00	0.00	0.00	0.00	45000.00	9000.00	54000.00	2025-02-21 00:00:00	0.00	56555.00	0.00	0.00	11311.00	0.00	67866.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Charles Sands	Limited	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
51	AL243603	AL	MS	Sold	On Site	KT21 OMB	Land Rover	Defender 90	D300 X MHEV	Black	44000	2021	2021-03-28 23:00:00	SALEA6AW7M2055430	2024-02-27 00:00:00	0.00	0.00	0.00	0.00	54786.00	0.00	54786.00	2025-02-22 00:00:00	54350.00	0.00	0.00	0.00	0.00	0.00	54350.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Jason	Richardson	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
52	AL243840	AL	MS	Sold	On Site	PE22 VUL	Land Rover	Defender 110	X-DYN HSE P400e	Black	36500	2022	2022-04-06 23:00:00	SALEA7AY0P2115155	2024-10-25 23:00:00	0.00	0.00	0.00	0.00	45365.83	9073.17	54439.00	2025-02-23 00:00:00	6875.00	46354.17	0.00	0.00	10645.83	0.00	63875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	TEXA Threat	Solutions Ltd	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
53	AL243891	AL	MS	Sold	On Site	CV21 PXF	Land Rover	Sport	ABIO DYN D300	Blue	57800	2021	2021-05-06 23:00:00	SALWA2AW6MA792721	2024-12-09 00:00:00	0.00	0.00	0.00	0.00	35000.00	0.00	35000.00	2025-02-23 00:00:00	13500.00	0.00	0.00	31375.00	0.00	0.00	44875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Bodhan	Dankowycz	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
29	AL253899	AL	MS	Sold	On Site	WD74 HHL	VW	Amarok	Dcab PanAmerica V6	Grey	200	2025	2025-01-03 00:00:00	WV4ZZZT11RS025621	2025-01-03 00:00:00	0.00	0.00	0.00	0.00	46000.00	9200.00	55200.00	2025-01-28 00:00:00	55833.33	0.00	0.00	0.00	11166.67	0.00	67000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	AG Wilson	Civil Engineering	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
30	AL243897	AL	MS	Sold	On Site	EK20 YLU	Audi	R8	Performance 4x4	Black	17000	2020	2020-06-30 23:00:00	SAL1A2A40PA103396	2024-12-20 00:00:00	0.00	2000.00	0.00	61795.05	21842.95	0.00	85638.00	2025-01-29 00:00:00	13000.00	85500.00	0.00	0.00	0.00	0.00	98500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	David	Atkins	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
31	AL253913	AL	PX	Sold	On Site	SA21 GVK (2)	Land Rover	Defender 110	S 3.0 MHEV	Grey	47000	2021	2021-03-05 00:00:00	SALEA7AW4M2035982	2025-01-14 00:00:00	0.00	0.00	0.00	0.00	38000.00	0.00	38000.00	2025-01-31 00:00:00	46000.00	0.00	0.00	0.00	0.00	0.00	46000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
32	AL243774	AL	MS	Sold	On Site	PE70 STZ (2)	Land Rover	Defender 110	2.0 SD4 Auto 4WD	Blue	46000	2020	2020-09-02 23:00:00	SALEA7AN9L2008573	2024-08-03 23:00:00	0.00	0.00	0.00	23246.72	12253.28	0.00	35500.00	2025-02-01 00:00:00	11000.00	30875.00	0.00	0.00	0.00	0.00	41875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Jerry	O'Sullivan	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
59	AL243848	AL	PX	Sold	On Site	BK19 YJT	Mercedes	GLE 300	AMG Line Prem	Black	56000	2019	2019-03-14 00:00:00	WDC1671192A014355	2024-10-31 00:00:00	24000.00	0.00	0.00	0.00	0.00	0.00	24000.00	2025-02-27 00:00:00	32500.00	0.00	0.00	0.00	0.00	0.00	32500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Anthony	Ibeh	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
60	AL253908	AL	MS	Sold	On Site	MP73 XBV	Toyota	Landcruiser	Invincible 2.8D	Black	13000	2023	2023-12-24 00:00:00	JTEBR3FJ50K326148	2025-01-11 00:00:00	0.00	0.00	0.00	48688.71	6311.29	0.00	55000.00	2025-02-27 00:00:00	59875.00	0.00	0.00	0.00	0.00	0.00	59875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Mid Ulster	Cars Toyota	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
61	AL243852	AL	MS	Sold	On Site	GX68 ZLU	Audi	Q8	Vorsprung	Black	47357	2018	2018-09-20 23:00:00	WAUZZZF10KD004740	2024-11-05 00:00:00	0.00	0.00	0.00	0.00	39500.00	0.00	39500.00	2025-02-28 00:00:00	5000.00	41800.00	0.00	0.00	0.00	0.00	46800.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Shaun	MccMahon	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
62	AL243889	AL	PX	Sold	On Site	OE65 ATK	Land Rover	Evoque	HSE DYN-LUX	Black	90000	2015	2015-11-23 00:00:00	SALVA2AN7GH098425	2024-12-06 00:00:00	13000.00	0.00	0.00	0.00	0.00	0.00	13000.00	2025-03-01 00:00:00	9000.00	0.00	0.00	0.00	0.00	0.00	9000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	R & S	Performance	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
63	AL253909	AL	MS	Sold	On Site	VO70 JZH	Audi	Q8	S Line Tdi 50	Blue	49000	2020	2020-08-31 23:00:00	WAUZZZF1XLD019330	2025-01-11 00:00:00	0.00	0.00	0.00	0.00	33850.00	0.00	33850.00	2025-03-01 00:00:00	0.00	41875.00	0.00	0.00	0.00	0.00	41875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4461.14	450.00	332.00	\N	\N	\N	Adam	Bywater	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
64	AL253905	AL	MS	Sold	On Site	GY22 DCE	Toyota	Landcruiser	Invincible 2.8D	Red	19500	2022	2022-06-05 23:00:00	JTEBR3FJ20K243972	2025-01-09 00:00:00	0.00	0.00	0.00	0.00	49500.00	0.00	49500.00	2025-03-02 00:00:00	55250.00	0.00	0.00	0.00	0.00	0.00	55250.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1180.00	350.00	0.00	\N	\N	\N	Frank	Swindles	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
65	AL253938	AL	MS	Sold	On Site	MJ73 HSF	Land Rover	Sport	DYN-SE D300 MHEV	Black	14800	2023	2023-10-11 23:00:00	SAL1A2AW6RA158116	2025-02-10 00:00:00	0.00	0.00	0.00	0.00	70980.00	0.00	70980.00	2025-03-02 00:00:00	59500.00	0.00	0.00	0.00	0.00	9000.00	68500.00	11000.00	0.00	0.00	0.00	0.00	0.00	0.00	3480.00	350.00	0.00	\N	\N	\N	Rameez	Hussain	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
67	AL253937	AL	MS	Sold	On Site	FMZ 1042	Land Rover	Sport	DYN-SE D300 MHEV	Carpathian	30500	2023	2023-03-21 00:00:00	SAL1A2AW7PA126501	2025-02-10 00:00:00	0.00	0.00	0.00	0.00	65500.00	0.00	65500.00	2025-03-07 00:00:00	72675.00	0.00	0.00	0.00	0.00	0.00	72675.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1420.00	450.00	0.00	\N	\N	\N	AK Prestige	Autos Ltd	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
68	AL253941	AL	MS	Sold	On Site	KR22 XWU	Land Rover	Defender 110	X-DYN HSE D250 MHEV	Black	21500	2022	2022-06-19 23:00:00	SALEA7AW1P2110318	2025-02-17 00:00:00	0.00	0.00	0.00	0.00	48125.00	9625.00	57750.00	2025-03-07 00:00:00	3600.83	56995.00	0.00	0.00	11999.17	0.00	72595.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	6287.00	450.00	0.00	\N	\N	\N	Eco 7	Ltd	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
69	AL243838	AL	ZH	Sold	On Site	YH24 CVG	BMW	I5 eDrive	40 M Sport	Grey	2500	2024	2024-03-27 00:00:00	WBY32FK040CP76622	2024-10-24 23:00:00	0.00	0.00	0.00	0.00	48000.00	0.00	48000.00	2025-03-08 00:00:00	15000.00	30000.00	0.00	0.00	0.00	0.00	45000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1083.32	550.00	0.00	\N	\N	\N	Habbak	Watches	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
70	AL253932	AL	MS	Sold	On Site	EF23 FVL	Land Rover	Defender 110	X-DYN HSE P400e	Black	13350	2023	2023-06-29 23:00:00	SALEA7AY1P2221582	2025-02-07 00:00:00	0.00	0.00	0.00	0.00	66100.00	0.00	66100.00	2025-03-09 00:00:00	8000.00	65875.00	0.00	0.00	0.00	0.00	73875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1390.00	350.00	0.00	\N	\N	\N	Inderpal	Obhi	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
71	AL243873	AL	MS	Sold	On Site	KP21 XOA	Audi	Q7	Black Edtion	Purple	25000	2021	2021-03-29 23:00:00	WAUZZZ4M0MD023451	2024-11-22 00:00:00	0.00	0.00	0.00	0.00	40750.00	0.00	40750.00	2025-03-10 00:00:00	1000.00	40159.32	-11284.32	17000.00	0.00	0.00	46875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2785.15	250.00	332.00	\N	\N	\N	Sylvia	Smith	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
72	AL253923	AL	MS	Sold	On Site	RK23 ESF	Land Rover	Discovery	R-DYN HSE D300	Black	28000	2023	2023-03-08 00:00:00	SALRA2AW4P2476973	2025-01-25 00:00:00	0.00	0.00	0.00	0.00	41875.00	8375.00	50250.00	2025-03-10 00:00:00	46666.67	0.00	0.00	0.00	9333.33	0.00	56000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1646.00	450.00	0.00	\N	\N	\N	Mischelle	Byrne	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
73	AL253924	AL	MS	Sold	On Site	RK23 ETA	Land Rover	Discovey	R-DYN HSE D300	Eiger	30000	2023	2023-03-02 00:00:00	SALRA2AW6P2477767	2025-01-25 00:00:00	0.00	0.00	0.00	0.00	41666.67	8333.33	50000.00	2025-03-11 00:00:00	46666.67	0.00	0.00	0.00	9333.33	0.00	56000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1579.00	450.00	0.00	\N	\N	\N	Aimee	Charnock	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
74	AL253933	AL	MS	Sold	On Site	PL21 LJU	Land Rover	Defender 110	XS EDT P400e	Silicon	28900	2021	2021-07-25 23:00:00	SALEA7AY9N2080306	2025-02-08 00:00:00	0.00	0.00	0.00	0.00	51000.00	0.00	51000.00	2025-03-11 00:00:00	8500.00	50000.00	0.00	0.00	0.00	0.00	58500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3452.00	450.00	428.00	\N	\N	\N	Carol	Cochran	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
75	AL253920	AL	MS	Sold	On Site	AV69 NVC	Land Rover	Sport	ABIO DYN V8 P525	Portofinio	31467	2019	2019-11-15 00:00:00	SALWA2AE5LA894713	2025-01-22 00:00:00	0.00	0.00	0.00	0.00	30000.00	0.00	30000.00	2025-03-12 00:00:00	42742.00	0.00	0.00	0.00	0.00	0.00	42742.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3589.00	500.00	500.00	\N	\N	\N	Daniel	Brown	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
76	AL253927	AL	MS	Sold	On Site	PF72 GYV	Land Rover	Vogue	P530 V8 First Edition	Black	18000	2022	2022-12-08 00:00:00	SALKA9A78PA037462	2025-01-28 00:00:00	0.00	1000.00	0.00	90580.04	-3000.00	0.00	88580.04	2025-03-13 00:00:00	5000.00	95000.00	0.00	0.00	0.00	0.00	100000.00	2000.00	0.00	0.00	0.00	0.00	0.00	0.00	2899.00	250.00	0.00	\N	\N	\N	Claire	Sinfield	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
77	AL243797	AL	PX	Sold	On Site	WT18 GMG	VW	Touareg	V6 R-Line TDI	Whie	55000	2018	2018-07-15 23:00:00	WVGZZZCRZJD003698	2024-08-28 23:00:00	26000.00	0.00	0.00	0.00	0.00	0.00	26000.00	2025-03-14 00:00:00	26000.00	0.00	0.00	0.00	0.00	0.00	26000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	R & S	Performance	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
78	AL253916	AL	SH	Sold	On Site	YG20 DUV	BMW	X7	30D M Sport XDrive	Black	44100	2020	2020-03-23 00:00:00	WBACW820609C40124	2025-01-16 00:00:00	0.00	0.00	0.00	0.00	50872.00	0.00	50872.00	2025-03-14 00:00:00	20000.00	0.00	0.00	27875.00	0.00	0.00	47875.00	6375.00	0.00	0.00	0.00	0.00	0.00	0.00	322.99	250.00	428.00	\N	\N	Real PX - 22K	Awan	International	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
79	AL253922	AL	MS	Sold	On Site	GX23 ULT	Land Rover	Sport	DYN SE P440e	Black	28000	2023	2023-04-26 23:00:00	SAL1A2A40PA130047	2025-01-25 00:00:00	0.00	0.00	0.00	0.00	57458.33	11491.67	68950.00	2025-03-14 00:00:00	63750.00	0.00	0.00	0.00	12750.00	0.00	76500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1560.00	300.00	0.00	\N	\N	\N	Autotrading	International Ltd	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
55	AL253912	AL	ZH	Sold	On Site	GJ22 ZKP	Prosche	Taycan	Turbo Performance Plus	Black	25000	2022	2022-04-28 23:00:00	WP0ZZZY1ZNSA50851	2025-01-13 00:00:00	0.00	0.00	0.00	0.00	50000.00	0.00	50000.00	2025-02-23 00:00:00	3500.00	30000.00	0.00	28000.00	0.00	0.00	61500.00	2000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Nathan	Macdonald	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
56	AL253936	AL	MS	Sold	On Site	LN22 JKX	Mercedes	G Wagon	400D AMG Line Prem+	Black	28000	2022	2022-03-16 00:00:00	W1N4633502X429981	2025-02-09 00:00:00	0.00	0.00	0.00	0.00	100000.00	0.00	100000.00	2025-02-24 00:00:00	17087.31	100000.00	-67087.31	52000.00	0.00	0.00	102000.00	19700.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	19700k Cash (Project Managemnet)	Asif	Patel	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
57	AL253949	AL	PX	Sold	On Site	MJ23 OKW	Land Rover	Defender 90	D250 X-DYN HSE	Black	2023	2023	2023-03-26 23:00:00	SALEA6AW5P2196551	2025-02-24 00:00:00	-15087.31	0.00	0.00	67087.31	0.00	0.00	52000.00	2025-02-26 00:00:00	55275.00	0.00	0.00	0.00	0.00	0.00	55275.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Martin	Sheard UK Ltd	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
58	AL253950	AL	PX	Sold	On Site	KV68 PSZ	Land Rover	Sport	ABIO DYN SDV6	Grey	2018	2018	2018-09-03 23:00:00	SALWA2AKXKA816657	2025-02-26 00:00:00	31355.00	0.00	0.00	0.00	0.00	0.00	31355.00	2025-02-26 00:00:00	34600.00	0.00	0.00	0.00	0.00	0.00	34600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	JDT	Motors	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
85	AL253947	AL	PX	Sold	On Site	YC17 UDU	Land Rover	Sport	SVR 5.0 SC	Grey	70000	2017	2017-03-15 00:00:00	SALWA2EE8HA140996	2025-02-23 00:00:00	28000.00	0.00	0.00	0.00	0.00	0.00	28000.00	2025-03-20 00:00:00	35875.00	0.00	0.00	0.00	0.00	0.00	35875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	671.00	200.00	500.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
86	AL253964	AL	MS	Sold	On Site	KN23 LUO	Land Rover	Defender 110	XS EDT P400e	Black	3700	2023	2023-05-23 23:00:00	SALEA7AY4P2185533	2025-03-12 00:00:00	0.00	0.00	0.00	0.00	61975.00	0.00	61975.00	2025-03-20 00:00:00	12500.00	70500.00	0.00	0.00	0.00	0.00	83000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	9375.00	550.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
87	AL253969	AL	MS	Sold	On Site	PJ24 WME	Porsche	911	992 GT3 S-A	Black	1255	2024	2024-07-16 23:00:00	WP0ZZZ996RS261086	2025-03-14 00:00:00	0.00	0.00	0.00	0.00	150000.00	0.00	150000.00	2025-03-20 00:00:00	145000.00	0.00	0.00	0.00	0.00	0.00	145000.00	20000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	100.00	0.00	\N	\N	\N	Daniel	Gibson	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
88	AL253940	AL	MS	Sold	On Site	LN24 XVZ	Land Rover	Vogue	HSE D350 MHEV	Black	8400	2024	2024-03-27 00:00:00	SALKA9AW3RA216373	2025-02-16 00:00:00	0.00	0.00	0.00	0.00	92500.00	0.00	92500.00	2025-03-21 00:00:00	97875.00	0.00	0.00	0.00	0.00	0.00	97875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1067.54	250.00	0.00	\N	\N	\N	Craig	Pugh	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
89	AL253945	AL	PX	Sold	On Site	SA22 NPN	BMW	I4	M50D M Sport	Grey	57000	2022	2022-05-04 23:00:00	WBY32AW060FM77001	2025-02-21 00:00:00	-8852.52	0.00	0.00	38852.52	0.00	0.00	30000.00	2025-03-21 00:00:00	33875.00	0.00	0.00	0.00	0.00	0.00	33875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	320.00	200.00	332.00	\N	\N	\N	Steven	Robinson	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
90	AL253954	AL	MS	Sold	On Site	KW23 BZG	Land Rover	Defender 110	D300 X-DYN HSE 7 STR	Black	11900	2023	2023-05-15 23:00:00	SALEA7AW0P2213830	2025-03-03 00:00:00	0.00	0.00	0.00	0.00	62000.00	0.00	62000.00	2025-03-24 00:00:00	72875.00	0.00	0.00	0.00	0.00	0.00	72875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3407.00	450.00	0.00	\N	\N	\N	Michael	Bottle	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
91	AL253973	AL	PX	Sold	On Site	XIG 1817	Audi	S5	TFSI Quattro	Grey	17500	2019	2019-02-09 00:00:00	WAUZZZF56JA106112	2025-03-19 00:00:00	-835.00	0.00	0.00	25335.00	0.00	0.00	24500.00	2025-03-24 00:00:00	24500.00	0.00	0.00	0.00	0.00	0.00	24500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	JDT	Motors	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
92	AL253979	AL	MS	Sold	On Site	FN23 EUW	Porsche	Macan	Estate 5dr PDK	Grey	9770	2023	2023-03-01 00:00:00	WP1ZZZ957PLB10731	2025-03-24 00:00:00	0.00	0.00	0.00	0.00	47409.00	0.00	47409.00	2025-03-24 00:00:00	8500.00	39000.00	0.00	0.00	0.00	0.00	47500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
93	AL243858	AL	ZH	Sold	On Site	DU22 MLO	Land Rover	Defender 110	D250 XS EDTION	Silver	33700	2022	2022-05-13 23:00:00	SALEA7AW4P2118705	2024-11-11 00:00:00	0.00	0.00	0.00	0.00	51500.00	0.00	51500.00	2025-03-26 00:00:00	27620.00	0.00	0.00	38000.00	0.00	0.00	65620.00	0.00	0.00	0.00	620.00	0.00	0.00	0.00	7707.00	400.00	428.00	\N	\N	\N	Nafisa	Patel	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
94	AL253939	AL	MS	Sold	On Site	DY23 KPJ	Land Rover	Sport	Autobiography P440e	Black	41800	2023	2023-04-18 23:00:00	SAL1A2A47PA132975	2025-02-13 00:00:00	0.00	0.00	0.00	77605.47	-4255.47	0.00	73350.00	2025-03-26 00:00:00	8000.00	71875.00	0.00	0.00	0.00	0.00	79875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1625.00	400.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
95	AL253980	AL	MS	Sold	On Site	DE73 ZTU	BMW	M3	Competion M Touring	Black	11700	2023	2023-10-31 00:00:00	WBS12GB090FR86090	2025-03-24 00:00:00	0.00	0.00	0.00	0.00	66000.00	0.00	66000.00	2025-03-26 00:00:00	54000.00	0.00	0.00	0.00	0.00	8000.00	62000.00	7250.00	0.00	600.00	0.00	0.00	0.00	0.00	0.00	100.00	0.00	\N	\N	We Paid Road Tax	Shabaz	Aslam	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
96	AL253943	AL	MS	Sold	On Site	WX69 UKO	Mercedes	C Class	C63S Premium Plus 4M	Black	24500	2019	2019-09-05 23:00:00	WDD2053872F951956	2025-02-21 00:00:00	0.00	0.00	0.00	27450.34	9249.66	0.00	36700.00	2025-03-27 00:00:00	3000.00	35875.00	0.00	0.00	0.00	0.00	38875.00	9000.00	0.00	0.00	0.00	0.00	0.00	0.00	1379.75	500.00	500.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
97	AL253952	AL	FA	Sold	On Site	CU25 SFE	Volkswagen	Amarok	Dcab PanAmerica V6	Grey	268	2025	2025-03-01 00:00:00	WV4ZZZT1XR5027402	2025-03-03 00:00:00	0.00	0.00	0.00	0.00	43000.00	8600.00	51600.00	2025-03-29 00:00:00	53805.00	0.00	0.00	0.00	10761.00	0.00	64566.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4006.73	350.00	0.00	\N	\N	\N	AJE	Thorley	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
98	AL243662	AL	MS	Sold	On Site	FJ18 DHZ	Lamborghini	Huracan	LP 610-4	Silver	2218	2018	2018-05-31 23:00:00	ZHWEC1ZFXHLA07777	2024-04-08 23:00:00	0.00	0.00	0.00	0.00	137000.00	0.00	137000.00	2025-03-31 23:00:00	28000.00	112000.00	0.00	0.00	0.00	0.00	140000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Maxwell	Williams	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
99	AL253944	AL	MS	Sold	On Site	RK69 UGG	VW	Amarok	Dcab Aventura V6	Blue	49000	2021	2021-07-12 23:00:00	SALEA7AY9N2071749	2025-02-24 00:00:00	0.00	0.00	0.00	0.00	25000.00	5000.00	30000.00	2025-03-31 23:00:00	368.96	25451.73	-13824.86	15000.00	5399.17	0.00	32395.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Derek	Holt	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
100	AL253958	AL	FA	Sold	On Site	FN25 MJJ	Volkswagen	Amarok	Dcab PanAmerica V6	Black	175	2025	2025-03-01 00:00:00	WV4ZZZT13R5027404	2025-03-05 00:00:00	0.00	0.00	0.00	0.00	43000.00	8600.00	51600.00	2025-03-31 23:00:00	19166.67	0.00	0.00	35000.00	10833.33	0.00	65000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4006.73	350.00	0.00	\N	\N	\N	Damian	Etherington	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
101	AL253956	AL	ZH	Sold	On Site	PF23 XEE	Porsche	Taycan 4	Cross Turismo	Grey	13700	2023	2023-06-25 23:00:00	WP0ZZZY12PSA58000	2025-03-03 00:00:00	0.00	0.00	0.00	0.00	49000.00	0.00	49000.00	2025-03-31 23:00:00	3740.18	56875.00	-39740.18	37000.00	0.00	0.00	57875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1441.00	350.00	0.00	\N	\N	\N	Fleetwood	Marine Services	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
102	AL253982	AL	MS	Sold	On Site	HG23 RCF	Land Rover	Defender 110	XS EDT P400e	Black	22000	2023	2023-08-14 23:00:00	SALEA7AY2R2252780	2025-03-25 00:00:00	0.00	0.00	0.00	54963.52	900.00	0.00	55863.52	2025-04-01 23:00:00	3360.00	66515.00	0.00	0.00	0.00	0.00	69875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3977.00	650.00	0.00	\N	\N	\N	Michael	Craig	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
103	AL212274	AL	AL	Sold	On Site	RJ68 ZCF	BMW	7 Series	740E M SPORT AUTO	Grey	22000	2018	2018-11-19 00:00:00	WBA7D02020B315092	2021-03-05 00:00:00	27875.00	0.00	0.00	0.00	0.00	0.00	27875.00	2025-04-03 23:00:00	1500.00	17500.00	0.00	0.00	0.00	0.00	19000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	-10457.00	250.00	331.52	\N	\N	\N	Javad	Mohammadi	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
104	AL253917	AL	PX	Sold	On Site	NU24 MVW	BMW	I5 eDrive	E40 M Sport	Black	10506	2024	2024-11-15 00:00:00	WBY32FK010CR21521	2025-01-16 00:00:00	42875.00	0.00	0.00	0.00	0.00	0.00	42875.00	2025-04-03 23:00:00	45700.00	0.00	0.00	0.00	0.00	0.00	45700.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	556.90	250.00	0.00	\N	\N	\N	John Henshall	Fruit Salesmand Ltd	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
105	AL253961	AL	MS	Sold	On Site	GX23 VTM	Land Rover	Vogue	SE P440e	Eiger	29800	2023	2023-03-24 00:00:00	SALKA9A43PA042011	2025-03-10 00:00:00	0.00	0.00	0.00	0.00	62916.67	12583.33	75500.00	2025-04-04 23:00:00	70000.00	0.00	0.00	0.00	14000.00	0.00	84000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1526.89	400.00	0.00	\N	\N	\N	ASL Auto	Services Ltd	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
81	AL243859	AL	ZH	Sold	On Site	ST71 BWV	BMW	X5	M50i	Black	22500	2021	2021-09-27 23:00:00	WBAJU420009J06874	2024-11-12 00:00:00	0.00	0.00	0.00	0.00	48757.00	0.00	48757.00	2025-03-15 00:00:00	5950.00	50835.00	-25335.00	24500.00	0.00	0.00	55950.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2610.00	350.00	500.00	\N	\N	\N	David	Andrew	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
82	AL253946	AL	PX	Sold	On Site	DO19 DDK	Audi	Q8	S Line Quattro	Grey	64000	2019	2019-08-29 23:00:00	WAUZZZF13KD005994	2025-02-23 00:00:00	31375.00	0.00	0.00	0.00	0.00	0.00	31375.00	2025-03-15 00:00:00	37065.00	0.00	0.00	0.00	0.00	0.00	37065.00	0.00	0.00	190.00	0.00	0.00	0.00	0.00	1282.03	300.00	332.00	\N	\N	\N	Luke	Beaumont	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
83	AL253930	AL	MS	Sold	On Site	WX23 ZGR	Land Rover	Defender 110	X-DYN HSE P400e	Eiger	19319	2023	2023-03-02 00:00:00	SALEA7AY3P2189086	2025-01-30 00:00:00	0.00	0.00	0.00	0.00	61269.00	0.00	61269.00	2025-03-19 00:00:00	10000.00	48875.00	0.00	16700.00	0.00	0.00	75575.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	5513.00	350.00	0.00	\N	\N	\N	Fank	Welch	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
84	AL253975	AL	MS	Sold	On Site	CF73 PUY	Land Rover	Defender 90	D300 X-DYN HSE	Eiger	9800	2024	2024-01-12 00:00:00	SALEA6AWXR2272350	2025-03-20 00:00:00	0.00	0.00	0.00	0.00	59500.00	0.00	59500.00	2025-03-19 00:00:00	10500.00	58000.00	0.00	0.00	0.00	0.00	68500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	5915.00	350.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
111	AL253996	AL	PX	Sold	On Site	YG14 GKJ	Land Rover	Discovery	GS	Grey	115000	2014	2014-03-30 23:00:00	SALLAAAG5EA711482	2025-04-08 23:00:00	4700.00	0.00	0.00	0.00	0.00	0.00	4700.00	2025-04-09 23:00:00	4700.00	0.00	0.00	0.00	0.00	0.00	4700.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	JDT	Motors	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
112	AL253966	AL	PX	Sold	On Site	BJ68 NLK	Mercedes	E Class	E220 AMG Premium	Grey	43000	2018	2018-09-20 23:00:00	WDD2384142F076340	2025-03-13 00:00:00	5715.68	0.00	0.00	11284.32	0.00	0.00	17000.00	2025-04-11 23:00:00	21875.00	0.00	0.00	0.00	0.00	0.00	21875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	615.00	350.00	331.52	\N	\N	\N	Gary	Fennah	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
113	AL253977	AL	MS	Sold	On Site	CY24 BEU	Land Rover	Sport	DYN-SE P460e	Borasco	7500	2024	2024-08-06 23:00:00	SAL1A2A44RA411531	2025-03-21 00:00:00	0.00	0.00	0.00	70995.89	7004.11	0.00	78000.00	2025-04-11 23:00:00	54700.00	0.00	0.00	34875.00	0.00	0.00	89575.00	0.00	0.00	620.00	80.00	0.00	0.00	0.00	3440.00	450.00	0.00	\N	\N	\N	D Mcnair Buliders	Merchants Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
114	AL253968	AL	PX	Sold	On Site	AE17 WYA	BMW	X5	30D M Sport	Black	60000	2017	2017-03-04 00:00:00	WBAKS420300J67845	2025-03-17 00:00:00	27875.00	0.00	0.00	0.00	0.00	0.00	27875.00	2025-04-13 23:00:00	10000.00	16500.00	0.00	0.00	0.00	0.00	26500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	-4642.00	250.00	331.52	\N	\N	Real 22k	Natalie	Trotter-King	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
115	AL253967	AL	MS	Sold	On Site	KT73 VTM	Land Rover	Sport	D300 DYN-SE	Borasco	21000	2023	2023-12-19 00:00:00	SAL1A2AW6RA177183	2025-03-13 00:00:00	0.00	500.00	0.00	0.00	70500.00	0.00	71000.00	2025-04-14 23:00:00	79000.00	0.00	0.00	0.00	0.00	0.00	79000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3705.00	350.00	0.00	\N	\N	\N	Angela	Lewis	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
116	AL254006	AL	MS	Sold	On Site	LS13 EAR	Mclaren	570	GT Coupe	Orange	6000	2017	2017-03-21 00:00:00	SBH13GAC0HW002456	2025-04-14 23:00:00	0.00	1875.00	0.00	56632.91	13367.09	0.00	71875.00	2025-04-14 23:00:00	78750.00	0.00	0.00	0.00	0.00	0.00	78750.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Mark	Aldhouse	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
117	AL254008	AL	SOR	Sold	On Site	DP70 TMV	Land Rover	Sport	SVR 5.0 SC	Red	52900	2021	2021-01-23 00:00:00	SALWA2AE7MA771383	2025-04-14 23:00:00	0.00	0.00	0.00	44988.35	-2988.35	0.00	42000.00	2025-04-14 23:00:00	2016.01	42490.00	-18261.01	21875.00	0.00	0.00	48120.00	0.00	0.00	620.00	0.00	0.00	0.00	0.00	1616.00	450.00	427.84	\N	\N	\N	Anthony	Jepson	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
118	AL253981	AL	PX	Sold	On Site	BF18 JUC	VW	Amarok	Highline V6 TDI 4 Motion	Beige	42000	2018	2018-03-15 00:00:00	WV1ZZZ2HZJH016546	2025-03-24 00:00:00	20000.00	0.00	0.00	0.00	0.00	0.00	20000.00	2025-04-15 23:00:00	8080.00	0.00	0.00	18875.00	0.00	0.00	26955.00	0.00	0.00	0.00	80.00	0.00	0.00	0.00	740.00	300.00	331.52	\N	\N	\N	Daniel	McGovern	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
119	AL253976	AL	MS	Sold	On Site	AF25 XBZ	Land Rover	Defender 110	D350 X-DYN HSE	Black	150	2025	2025-03-19 00:00:00	SALEA7AW1S2431414	2025-03-21 00:00:00	0.00	0.00	0.00	0.00	65416.67	13083.33	78500.00	2025-04-15 23:00:00	0.00	74583.33	0.00	0.00	14916.67	0.00	89500.00	0.00	0.00	600.00	80.00	0.00	0.00	0.00	4226.00	350.00	0.00	\N	\N	\N	Stuart	Verth	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
120	AL253984	AL	MS	Sold	On Site	BA73 XDC (2)	Land Rover	Defender 110	X-DYN HSE P400e	Black	23700	2023	2023-10-31 00:00:00	SALEA7AY0R2275412	2025-03-26 00:00:00	0.00	0.00	0.00	0.00	64000.00	0.00	64000.00	2025-04-16 23:00:00	13908.63	59966.37	0.00	0.00	0.00	0.00	73875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	315.00	450.00	0.00	\N	\N	\N	Kiasu	Workforce LTd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
121	AL253915	AL	MS	Sold	On Site	RJ21 ZBT	Land Rover	Vogue	ABIO P400e	Carpathian	36000	2021	2021-04-22 23:00:00	SALGA2AYXMA445575	2025-01-16 00:00:00	0.00	0.00	0.00	44848.08	-3248.08	0.00	41600.00	2025-04-20 23:00:00	4750.00	42625.00	0.00	0.00	0.00	0.00	47375.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1144.65	400.00	427.84	\N	\N	\N	Livingston	Solomon	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
122	AL253988	AL	PX	Sold	On Site	LT17 UHB (2)	Land Rover	Sport	HSE SDV6	White	87000	2017	2017-05-09 23:00:00	SALWA2EK7HA142003	2025-04-04 23:00:00	16700.00	0.00	0.00	0.00	0.00	0.00	16700.00	2025-04-21 23:00:00	16700.00	0.00	0.00	0.00	0.00	0.00	16700.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	JDT	Motors	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
123	AL254013	AL	PX	Sold	On Site	SH21 DYD (2)	Land Rover	Sport	D300 HSE Dyn	Grey	37000	2021	2021-04-28 23:00:00	SALWA2AW5MA785730	2025-04-17 23:00:00	38000.00	0.00	0.00	0.00	0.00	0.00	38000.00	2025-04-21 23:00:00	38000.00	0.00	0.00	0.00	0.00	0.00	38000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	JDT	Motors	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
124	AL253978	AL	MS	Sold	On Site	KR23 OAS	Land Rover	Sport	Autobiography P440e	Black	32500	2023	2023-05-26 23:00:00	SAL1A2A41PA134396	2025-03-23 00:00:00	0.00	0.00	0.00	0.00	77399.00	0.00	77399.00	2025-04-22 23:00:00	3800.00	75600.00	0.00	0.00	0.00	0.00	79400.00	4600.00	0.00	0.00	0.00	0.00	0.00	0.00	640.00	300.00	0.00	\N	\N	\N	Margaret	Paterson	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
125	AL253972	AL	MS	Sold	On Site	KS72 VDG	Land Rover	Defender 110	X-DYN SE P400e	Eiger	9600	2023	2023-01-06 00:00:00	SALEA7AY7P2175160	2025-03-17 00:00:00	0.00	0.00	0.00	0.00	57491.00	0.00	57491.00	2025-04-22 23:00:00	66500.00	0.00	0.00	0.00	0.00	0.00	66500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3827.00	450.00	0.00	\N	\N	\N	Wingnut	Utilities Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
126	AL254001	AL	MS	Sold	On Site	EJ73 VLH	Land Rover	Sport	ABIO P460e	Varesine	14300	2023	2023-11-17 00:00:00	SAL1A2A41RA160774	2025-04-10 23:00:00	0.00	0.00	0.00	0.00	80500.00	0.00	80500.00	2025-04-27 23:00:00	40000.00	49875.00	0.00	0.00	0.00	0.00	89875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4080.00	350.00	0.00	\N	\N	\N	Kashif	Adams	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
127	AL253994	AL	MS	Sold	On Site	KJ23 HHE	Land Rover	Defender 110	X-DYN HSE P400e	Eiger	18611	2023	2023-07-26 23:00:00	SALEA7AY7R2245212	2025-04-08 23:00:00	0.00	0.00	0.00	0.00	52916.67	10583.33	63500.00	2025-04-27 23:00:00	18766.67	31000.00	0.00	9400.00	11833.33	0.00	71000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3667.00	300.00	0.00	\N	\N	\N	Fibre Arts	Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
128	AL253998	AL	MS	Sold	On Site	KR24 UZT	Land Rover	Defender 110	D300 X-DYN SE 7 STR	Black	12800	2024	2024-03-28 00:00:00	SALEA7AW8R2316559	2025-04-09 23:00:00	0.00	0.00	0.00	0.00	52375.00	10475.00	62850.00	2025-05-01 23:00:00	60416.67	0.00	0.00	0.00	12083.33	0.00	72500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3652.00	300.00	0.00	\N	\N	\N	Wenlock	Wardrobe	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
129	AL253925	AL	MS	Sold	On Site	SC21 LCT	Land Rover	Vogue	Westminster BLK D300	Black	33000	2021	2021-06-24 23:00:00	SALGA2AW3MA453001	2025-01-27 00:00:00	0.00	0.00	0.00	0.00	41000.00	0.00	41000.00	2025-05-01 23:00:00	30000.00	18575.00	0.00	0.00	0.00	0.00	48575.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2261.00	550.00	427.84	\N	\N	\N	Tasleem	Hussain	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
130	AL253971	AL	MS	Sold	On Site	LO21 KLL	Audi	S5	Edition 1 MHEV	Grey	39000	2021	2021-05-13 23:00:00	WAUZZZF56MA042271	2025-03-16 00:00:00	0.00	0.00	0.00	0.00	27250.00	0.00	27250.00	2025-05-01 23:00:00	1000.00	31875.00	0.00	0.00	0.00	0.00	32875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	240.00	250.00	331.52	\N	\N	\N	John	Smith	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
107	AL253921	AL	MS	Sold	On Site	OE69 YPL	Land Rover	Vogue	SE P400e Hybrid	Eiger	97000	2020	2020-01-08 00:00:00	SALGA2AY7LA596503	2025-01-23 00:00:00	0.00	0.00	0.00	0.00	21000.00	0.00	21000.00	2025-04-06 23:00:00	2000.00	25875.00	0.00	0.00	0.00	0.00	27875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1444.00	300.00	427.84	\N	\N	\N	David	Withnell	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
108	AL253963	AL	MS	Sold	On Site	AE25 SWW	Land Rover	Defender 110	D250 X-DYN HSE	Black	150	2025	2025-03-01 00:00:00	SALEA7AW3S2415344	2025-03-20 00:00:00	0.00	0.00	0.00	0.00	73000.00	0.00	73000.00	2025-04-07 23:00:00	22000.00	59000.00	0.00	0.00	0.00	0.00	81000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2782.00	350.00	0.00	\N	\N	\N	Jason	Hart	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
109	AL253955	AL	MS	Sold	On Site	KS23 YZU	Land Rover	Defender 110	D300 X-DYN HSE 7 STR	Eiger	17000	2023	2023-05-14 23:00:00	SALEA7AWXP2214595	2025-03-03 00:00:00	0.00	0.00	0.00	0.00	60400.00	0.00	60400.00	2025-04-08 23:00:00	72495.00	0.00	0.00	0.00	0.00	0.00	72495.00	0.00	0.00	620.00	0.00	0.00	0.00	0.00	5447.00	350.00	0.00	\N	\N	\N	Give Brite	Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
110	AL253942	AL	MS	Sold	On Site	YC21 XDN	Land Rover	Defender 110	D200 SE MHEV 7 STR	Eiger	48000	2021	2021-03-30 23:00:00	SALEA7AW1M2053887	2025-02-21 00:00:00	0.00	0.00	0.00	0.00	40000.00	0.00	40000.00	2025-04-08 23:00:00	0.00	42875.00	0.00	4700.00	0.00	0.00	47575.00	500.00	0.00	0.00	0.00	0.00	0.00	0.00	2548.00	450.00	427.84	\N	\N	\N	Xuewen	Chen	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
137	AL254016	AL	PX	Sold	On Site	SK21 XBW	BMW	X5	xDrivee 45e M Sport	Black	48000	2021	2021-03-01 00:00:00	WBATA620X09F48674	2025-04-24 23:00:00	34875.00	0.00	0.00	0.00	0.00	0.00	34875.00	2025-05-08 23:00:00	39500.00	0.00	0.00	0.00	0.00	0.00	39500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	884.86	450.00	0.00	\N	\N	\N	AAA	Stars Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
138	AL254015	AL	FA	Sold	On Site	LM73 MGJ	Land Rover	Defender 110	X-DYN HSE D300 MHEV	Carpathian	8300	2024	2024-01-23 00:00:00	SALEA7AW1R2287728	2025-04-23 23:00:00	0.00	0.00	0.00	62279.93	1700.00	0.00	63979.93	2025-05-08 23:00:00	22500.00	0.00	0.00	50000.00	0.00	0.00	72500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1421.42	350.00	0.00	\N	\N	\N	Claire	Brown	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
139	AL254011	AL	MS	Sold	On Site	SO22 WUW	Land Rover	Sport	SVR 5.0 SC	Black	29500	2022	2022-06-20 23:00:00	SALWA2AE1NA242674	2025-04-16 23:00:00	0.00	0.00	0.00	55887.66	-4887.66	0.00	51000.00	2025-05-11 23:00:00	59500.00	0.00	0.00	0.00	0.00	0.00	59500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3408.22	350.00	428.00	\N	\N	\N	Melissa	Johnson	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
140	AL254041	AL	SOR	Sold	On Site	HK20 MVP (2)	Land Rover	Defender 110	D240 HSE	Black	38800	2020	2020-07-06 23:00:00	SALEA7AN7L2009267	2025-05-11 23:00:00	0.00	0.00	0.00	0.00	44780.00	0.00	44780.00	2025-05-11 23:00:00	4000.00	50875.00	-40563.90	38000.00	0.00	0.00	52311.10	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1513.96	450.00	428.00	\N	\N	\N	Samatha	Jackson	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
141	AL254032	AL	MS	Sold	On Site	HG73 KYJ	Land Rover	Sport	D300 DYN-SE	Black	15000	2023	2023-10-25 23:00:00	SAL1A2AW0RA166924	2025-05-05 23:00:00	0.00	500.00	0.00	0.00	64500.00	0.00	65000.00	2025-05-11 23:00:00	71244.06	0.00	-101244.06	101000.00	0.00	0.00	71000.00	2120.00	0.00	620.00	0.00	0.00	0.00	0.00	50.00	250.00	0.00	\N	\N	\N	Asif	Patel	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
142	AL253970	AL	MS	Sold	On Site	DS23 CAE	Land Rover	Defender 110	D250 X-DYN HSE	Lantau	38500	2023	2023-04-19 23:00:00	SALEA7AW8P2205605	2025-03-15 00:00:00	0.00	0.00	0.00	0.00	58200.00	0.00	58200.00	2025-05-13 23:00:00	6588.00	59287.00	0.00	0.00	0.00	0.00	65875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3399.44	300.00	0.00	\N	\N	\N	Rachel	Riding	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
143	AL243872	AL	PX	Sold	On Site	MF19 ZXY	BMW	X6	40D M Sport	White	73000	2019	2019-03-30 00:00:00	WBAKV420900Z98709	2024-11-22 00:00:00	21200.00	0.00	0.00	0.00	0.00	0.00	21200.00	2025-05-14 23:00:00	0.00	29002.00	-9127.91	6500.00	0.00	0.00	26374.09	0.00	0.00	0.00	0.00	0.00	0.00	0.00	574.00	450.00	332.00	\N	\N	\N	Thomas	Entwistle	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
144	AL254022	AL	MS	Sold	On Site	HSZ 6020	BMW	M3	Competition M Est	Tanzanite	6500	2023	2023-06-25 23:00:00	WBS12GB090FR23037	2025-04-26 23:00:00	0.00	0.00	0.00	0.00	65000.00	0.00	65000.00	2025-05-15 23:00:00	70000.00	0.00	0.00	0.00	0.00	0.00	70000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Sytner	Motor Group	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
145	AL254038	AL	ZH	Sold	On Site	KE70 XWF	Land Rover	Velar	R DYN-SE D300	Black	40000	2021	2021-02-06 00:00:00	SALYA2AW8MA298773	2025-05-07 23:00:00	0.00	0.00	0.00	0.00	27200.00	0.00	27200.00	2025-05-22 23:00:00	5250.00	26782.21	-15407.21	16250.00	0.00	0.00	32875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	819.00	300.00	428.00	\N	\N	\N	Henry	Truman	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
146	AL253990	AL	PX	Sold	On Site	BN67 XOO	Ford	Ranger	2.2 TDCI	Blue	70000	2017	2017-09-27 23:00:00	6FPPXMJ2PHU50520	2025-04-07 23:00:00	1175.14	0.00	0.00	13824.86	0.00	0.00	15000.00	2025-05-23 23:00:00	15000.00	0.00	0.00	0.00	0.00	0.00	15000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	MSR	Prestige	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
147	AL254009	AL	PX	Sold	On Site	EJ20 KFN	Ford	Raptor	EcoBlue 4x4	Black	52000	2020	2020-07-29 23:00:00	6FPPXXMJ2PLB75772	2025-04-14 23:00:00	21875.00	0.00	0.00	0.00	0.00	0.00	21875.00	2025-05-23 23:00:00	24000.00	0.00	0.00	0.00	0.00	0.00	24000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	MSR	Prestige	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
148	AL254019	AL	MS	Sold	On Site	RO24 TZZ	Land Rover	Defender 110	X-DYN HSE P400e	Black	15600	2024	2024-03-07 00:00:00	SALEA7AY5R2312390	2025-04-25 23:00:00	0.00	0.00	0.00	0.00	68500.00	0.00	68500.00	2025-05-23 23:00:00	10000.00	60000.00	0.00	0.00	0.00	0.00	70000.00	6000.00	0.00	0.00	0.00	0.00	0.00	0.00	1694.00	350.00	0.00	\N	\N	6K cash OB	JMTK  Property	Invest LTd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
149	AL253987	AL	PX	Sold	On Site	VU21 TOV	Volkswagen	Touareg	V6 Black Edition	White	38000	2021	2021-03-05 00:00:00	WVGZZZCRZMD023352	2025-04-03 23:00:00	29166.67	0.00	0.00	0.00	0.00	5833.33	35000.00	2025-05-23 23:00:00	363.55	33447.04	0.00	0.00	6689.41	0.00	40500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1948.23	450.00	332.00	\N	\N	\N	Michelle	Mcderra	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
150	AL243886	AL	MS	Sold	On Site	FX22 PVL	Land Rover	Sport	HSE DYN 3.0D	Black	44000	2022	2022-03-16 00:00:00	SALWA2AW1NA237600	2024-12-05 00:00:00	0.00	0.00	0.00	23280.20	15219.80	0.00	38500.00	2025-05-25 23:00:00	5000.00	36875.00	0.00	0.00	0.00	0.00	41875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1360.91	450.00	427.84	\N	\N	\N	Graham	Adamson	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
151	AL253991	AL	ZH	Sold	On Site	RK21 BXA	Land Rover	Defender 110	D300 SE COMM	Grey	38000	2021	2021-04-14 23:00:00	SALEAJAW2M2054723	2025-04-07 23:00:00	0.00	0.00	0.00	0.00	40000.00	8000.00	48000.00	2025-05-26 23:00:00	2904.64	45000.00	0.00	0.00	10095.36	3000.00	61000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3165.00	450.00	427.84	\N	\N	\N	Turtle	Fisheries Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
152	AL254042	AL	MS	Sold	On Site	GF24 HDD	Audi	SQ8	Black Edtion TFSi	Blue	9097	2024	2024-03-27 00:00:00	WAUZZZF11PD049287	2025-05-11 23:00:00	0.00	0.00	0.00	0.00	63500.00	0.00	63500.00	2025-05-27 23:00:00	10000.00	27327.96	-23327.96	58000.00	0.00	0.00	72000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2810.00	350.00	0.00	\N	\N	\N	Nigel	Challinor	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
153	AL254037	AL	ZH	Sold	On Site	CX21 YPR	Mercedes	GLE 300	AMG Line Prem	Blue	59800	2021	2021-03-30 23:00:00	W1N1671192A251887	2025-05-07 23:00:00	0.00	0.00	0.00	24200.00	7000.00	0.00	31200.00	2025-05-28 23:00:00	230.00	34801.75	-13801.75	16270.00	0.00	0.00	37500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1718.00	350.00	332.00	\N	\N	\N	Kieran	Anderton	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
154	AL254023	AL	MS	Sold	On Site	BJ23 OBR	Land Rover	Sport	D300 ABIO MHEV	Black	23474	2023	2023-05-29 23:00:00	SAL1A2AW5PA138274	2025-04-26 23:00:00	0.00	0.00	0.00	0.00	72000.00	0.00	72000.00	2025-05-28 23:00:00	25000.00	53875.00	0.00	0.00	0.00	0.00	78875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	730.00	300.00	0.00	\N	\N	\N	Electrical Hire	Services Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
155	AL254054	AL	ZR	Sold	On Site	KR70 EPP	Audi	Q8	S Line 50 TDI	Blue	69400	2020	2020-11-16 00:00:00	WAUZZZF11MD003423	2025-05-27 23:00:00	0.00	0.00	0.00	0.00	34995.00	0.00	34995.00	2025-06-02 23:00:00	0.00	0.00	34995.00	0.00	0.00	0.00	34995.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Kevin	Farrell	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
183	AL243762	AL	MS	Stock	On Site	YN23 WWF	Land Rover	Sport	DYN SE D300	Black	18000	2023	2023-03-02 00:00:00	SAL1A2AW8PA117970	2024-07-24 23:00:00	0.00	0.00	0.00	0.00	67369.00	0.00	67369.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Jetan	Sadiku	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
133	AL254014	AL	PX	Sold	On Site	YX21 CWR	Mitsubishi	Shogun	Sport DI-D 4 Auto	Bronze	45600	2021	2021-04-30 23:00:00	MMAGUKS10JH002911	2025-04-17 23:00:00	18875.00	0.00	0.00	0.00	0.00	0.00	18875.00	2025-05-02 23:00:00	22875.00	0.00	0.00	0.00	0.00	0.00	22875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	215.00	300.00	331.52	\N	\N	\N	Helena	Carter	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
134	AL253993	AL	MS	Sold	On Site	LL74 CKN	Land Rover	Vogue	ABIO P460e	Carpathian	11000	2024	2024-09-02 23:00:00	SALKA9A47RA237600	2025-04-08 23:00:00	0.00	0.00	0.00	76288.28	25550.00	0.00	101838.28	2025-05-06 23:00:00	9032.00	107843.00	-71908.17	77000.00	0.00	0.00	121966.83	0.00	0.00	0.00	0.00	0.00	0.00	0.00	8419.16	450.00	0.00	\N	\N	\N	Bambinos Boutitique	Daycare Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
135	AL253999	AL	MS	Sold	On Site	HG23 BSY	Land Rover	Sport	P400 ABIO MHEV	Black	16300	2023	2023-04-05 23:00:00	SAL1A2AU5PA128665	2025-04-09 23:00:00	0.00	500.00	0.00	0.00	74100.00	0.00	74600.00	2025-05-06 23:00:00	21125.00	63875.00	0.00	0.00	0.00	0.00	85000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3680.00	200.00	724.86	\N	\N	\N	Alentar	Care Limited	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
136	AL254007	AL	MS	Sold	On Site	KT23 UTZ	Land Rover	Defender 110	D300 X-DYN HSE 7 STR	Black	26750	2023	2023-06-19 23:00:00	SALEA7AW0P2210930	2025-04-14 23:00:00	0.00	0.00	0.00	0.00	51250.00	10250.00	61500.00	2025-05-06 23:00:00	58229.17	0.00	0.00	0.00	11645.83	0.00	69875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3622.00	350.00	0.00	\N	\N	\N	A & R Cook	Son Ltd	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
161	AL253992	AL	MS	Sold	On Site	KR23 SKN	Land Rover	Defender 110	D300 X-DYN HSE 7 STR	Black	24600	2023	2023-04-05 23:00:00	SALEA7AW0P2205307	2025-04-08 23:00:00	0.00	0.00	0.00	0.00	52291.67	10458.33	62750.00	2025-06-13 23:00:00	59166.67	0.00	0.00	0.00	11833.33	0.00	71000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	3297.00	450.00	0.00	\N	\N	\N	Agilitee	Limited	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
162	AL254026	AL	MS	Sold	On Site	KO73 OVR	Land Rover	Sport	D300 DYN-SE	Black	6900	2024	2024-01-16 00:00:00	SAL1A2AWXRA158121	2025-04-28 23:00:00	0.00	0.00	0.00	0.00	70000.00	0.00	70000.00	2025-06-13 23:00:00	52000.00	0.00	0.00	24000.00	0.00	0.00	76000.00	4000.00	0.00	0.00	0.00	0.00	0.00	0.00	1310.00	550.00	0.00	\N	\N	\N	Joshua	Abbott	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
163	AL253959	AL	MS	Sold	On Site	KR73 AFJ	Land Rover	Sport	D300 X-DYN SE	Charente	19850	2023	2023-09-26 23:00:00	SAL1A2AW7RA161123	2025-03-07 00:00:00	0.00	0.00	0.00	0.00	68500.00	0.00	68500.00	2025-06-15 23:00:00	20000.00	36596.76	-5921.76	24000.00	0.00	0.00	74675.00	0.00	0.00	620.00	0.00	0.00	0.00	0.00	1310.00	550.00	0.00	\N	\N	\N	Duncan	Hill	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
164	AL254067	AL	ZH	Sold	On Site	DV25 ZPJ	Land Rover	Defender 110	D350 X Dyn HSE Comm	Carpathian	150	2025	2025-06-01 23:00:00	SALEAJAWOS456012	2025-06-03 23:00:00	0.00	0.00	0.00	0.00	69460.00	13892.00	83352.00	2025-06-15 23:00:00	82465.67	0.00	0.00	0.00	16493.13	0.00	98958.80	0.00	0.00	0.00	0.00	0.00	0.00	0.00	8350.00	350.00	0.00	\N	\N	\N	JMC NW	Limited Joe	2025-06-26 08:09:24.508	2025-06-26 10:21:18.118
165	AL253985	AL	MS	Sold	On Site	LJ23 XVZ	Land Rover	Sport	D300 DYN-SE	Varesine	26200	2023	2023-06-27 23:00:00	SAL1A2AW0PA103299	2025-03-29 00:00:00	0.00	0.00	0.00	63172.66	500.00	0.00	63672.66	2025-06-16 23:00:00	68500.00	0.00	0.00	0.00	0.00	0.00	68500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	740.00	350.00	0.00	\N	\N	\N	Lee	Simmons	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
166	AL254062	AL	ZH	Sold	On Site	MM20 WLG	Land Rover	Evoque	P250 R Dynamic HSE	Black	47573	2020	2020-03-20 00:00:00	SALZA2AX2LH090083	2025-06-01 23:00:00	0.00	0.00	0.00	0.00	19000.00	0.00	19000.00	2025-06-16 23:00:00	25500.00	0.00	0.00	0.00	0.00	0.00	25500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1233.28	350.00	428.00	\N	\N	\N	Vismantas	Uselis	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
173	AL222774	AL	AL	Stock	On Site	RE11 FYL	Mercedes	C Class	C220	Silver	120000	2011	2011-05-15 23:00:00	WDD2040022A557758	2017-08-01 23:00:00	0.00	0.00	0.00	8351.07	0.00	0.00	8351.07	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
168	AL254059	MSR	ZR	Sold	On Site	SG18 UDS	Land Rover	Sport	HSE SDV6	Black	62000	2018	2018-03-20 00:00:00	SALWA2AK5JA401969	2025-05-29 23:00:00	0.00	0.00	0.00	0.00	19200.00	0.00	19200.00	2025-06-18 23:00:00	19726.80	0.00	0.00	0.00	0.00	0.00	19726.80	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	MSR	Prestige Ltd	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
169	AL254055	AL	ZH	Sold	On Site	KM19 EZU	Land Rover	Velar	R DYN-HSE D300	Eiger Grey	62500	2019	2019-03-01 00:00:00	SALYA2AK8KA218494	2025-05-27 23:00:00	0.00	0.00	0.00	0.00	20250.00	0.00	20250.00	2025-06-19 23:00:00	27500.00	0.00	0.00	0.00	0.00	0.00	27500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1612.65	450.00	428.00	\N	\N	\N	Lorraine	Vernon Fuller	2025-06-26 08:09:24.508	2025-06-30 10:03:42.214
170	AL254056	AL	PX	Sold	On Site	CF72 SZG	Porsche	Macan	GTS S-A	Crayon	27632	2022	2022-12-29 00:00:00	WP1ZZZ952PLB42440	2025-05-29 23:00:00	58000.00	0.00	0.00	0.00	0.00	0.00	58000.00	2025-06-19 23:00:00	7800.00	30000.00	0.00	27000.00	0.00	0.00	64800.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	640.00	350.00	0.00	\N	\N	\N	Deborah	Puddicome	2025-06-26 08:09:24.508	2025-07-02 21:15:31.362
171	AL254044	AL	PX	Sold	On Site	KR73 UAA	Land Rover	Discovery	Dynamic HSE D300	Silicon	9570	2023	2023-10-09 23:00:00	SALRA2AW8R2490409	2025-05-13 23:00:00	50000.00	0.00	0.00	0.00	0.00	0.00	50000.00	2025-06-19 23:00:00	55750.00	0.00	0.00	0.00	0.00	0.00	55750.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	932.00	450.00	0.00	\N	\N	\N	Tracey	Hardisty	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
172	AL212584	AL	AL	Stock	On Site	PK70 PUJ	BMW	1 Series	116D M Sport	Grey	12000	2020	2020-11-12 00:00:00	WBA7M720407H12365	2021-09-05 23:00:00	0.00	0.00	0.00	0.00	24490.00	0.00	24490.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
159	AL254045	AL	PX	Sold	On Site	WD71 JGU	Audi	Q7 S Line	Black Edtion	Black	30000	2021	2022-02-07 00:00:00	WAUZZZ4M3ND011974	2025-05-15 23:00:00	-2563.90	0.00	0.00	40563.90	0.00	0.00	38000.00	2025-06-10 23:00:00	4530.00	41000.00	0.00	0.00	0.00	0.00	45530.00	1500.00	0.00	0.00	0.00	0.00	0.00	0.00	3381.00	450.00	332.52	\N	\N	\N	Michael	Wainwright	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
174	AL222778	AL	PX	Stock	On Site	BU16 TVY	Mercedes	C Class	C220 D AMG Line	Blue	53734	2016	2016-03-08 00:00:00	WDD2052042F353576	2022-01-14 00:00:00	15000.00	0.00	0.00	0.00	0.00	0.00	15000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
175	AL222883	AL	MS	Stock	On Site	HW22 AEJ	Porsche	Taycan	Turbo S Cross Turismo	Grey	100	2022	2022-03-23 00:00:00	WP0ZZZY1ZNSA72636	2022-04-06 23:00:00	0.00	0.00	0.00	0.00	134166.67	26833.33	161000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
176	AL223104	AL	MS	Stock	On Site	BD15 VEL	Ford	Fiesta	Red Edition	Red	64000	2015	2015-05-12 23:00:00	WF0CXXGAKCFC03205	2022-10-10 23:00:00	0.00	0.00	0.00	0.00	6000.00	0.00	6000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
177	AL243586	AL	PX	Stock	On Site	KV66 KHH	Audi	A6 Avant	3.0 Black Edtion	Black	80000	2016	2016-10-09 23:00:00	WAUZZZ4G6HN034514	2024-02-10 00:00:00	16000.00	0.00	0.00	0.00	0.00	0.00	16000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
178	AL243665	AL	AL	Stock	On Site	FP68 UAC	Mercedes	C Class	C 43 PREMIUM + 4MATIC	White	38000	2018	2018-12-20 00:00:00	WDD2053642F836479	2024-04-10 23:00:00	0.00	0.00	0.00	0.00	27500.00	0.00	27500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
179	AL243699	AL	MS	Stock	On Site	LX20 LLA	Land Rover	Sport	HSE P400e	White	22600	2020	2020-03-10 00:00:00	SALWA2AY8LA732181	2024-05-12 23:00:00	0.00	0.00	0.00	0.00	26500.00	5300.00	31800.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
180	AL243706	AL	MS	Stock	On Site	LA22 NPE	Land Rover	Vogue	D350 ABIO LWB 7 STR	Eiger Grey	13300	2022	2022-07-25 23:00:00	SALKABAW3PA010071	2024-05-15 23:00:00	0.00	0.00	0.00	0.00	93050.00	0.00	93050.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
181	AL243715	AL	MS	Stock	On Site	LA08 OGR	Land Rover	Sport	HSE	Black	72000	2008	2008-07-16 23:00:00	SALLSAA138A185400	2024-05-26 23:00:00	2850.00	0.00	0.00	0.00	0.00	0.00	2850.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
182	AL243756	AL	SH	Stock	On Site	AE59 JUV	BMW	3 Series	M3 Semi Auto	Black	86100	2009	2009-11-17 00:00:00	WBSPM92090E198044	2024-07-22 23:00:00	0.00	0.00	0.00	0.00	14750.00	0.00	14750.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
157	AL254029	AL	MS	Sold	On Site	LO73 ZBX	Audi	R8	Performance QTR	Black	4600	2023	2023-11-30 00:00:00	WUAZZZFX6P7902064	2025-05-01 23:00:00	0.00	1000.00	0.00	76104.35	33595.65	0.00	110700.00	2025-06-09 23:00:00	123000.00	0.00	0.00	0.00	0.00	0.00	123000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	340.00	450.00	0.00	\N	\N	\N	Farooq	Munshi	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
158	AL254049	AL	MS	Sold	On Site	LC24 UUT	Land Rover	Defender 110	XS EDT P400e	Black	15000	2024	2024-05-30 23:00:00	SALEA7AY9R2324090	2025-05-18 23:00:00	0.00	0.00	0.00	62269.93	1730.07	0.00	64000.00	2025-06-10 23:00:00	71500.00	0.00	0.00	0.00	0.00	0.00	71500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2926.00	300.00	0.00	\N	\N	\N	Robert	Winter	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
167	AL254004	AL	MS	Sold	On Site	BT23 GGX	Land Rover	Defender 110	D250 X-DYN HSE 7 STR	Black	16300	2023	2023-05-03 23:00:00	SALEA7AW8P2208729	2025-04-13 23:00:00	0.00	0.00	0.00	0.00	62400.00	0.00	62400.00	2025-06-16 23:00:00	74000.00	0.00	0.00	0.00	0.00	0.00	74000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4541.00	550.00	0.00	\N	\N	\N	Daniel	Larssen	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
160	AL254021	AL	MS	Sold	On Site	NG22 ZRA	Land Rover	Vogue	D350 HSE MHEV	Black	15800	2022	2022-04-03 23:00:00	SALKA9AW2NA004235	2025-04-25 23:00:00	0.00	0.00	0.00	0.00	75500.00	0.00	75500.00	2025-06-10 23:00:00	7500.00	75000.00	0.00	0.00	0.00	0.00	82500.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	776.00	350.00	428.00	\N	\N	\N	Michael	Rigg	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
185	AL243865	AL	MS	Stock	On Site	LO23 XUH	Land Rover	Defender 110	X-DYN HSE P400e	Black	27000	2023	2023-06-18 23:00:00	SALEA7AY7P2223255	2024-11-18 00:00:00	0.00	0.00	0.00	0.00	62500.00	0.00	62500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
189	AL253951	AL	ZH	Sold	On Site	YD73 GSN	Land Rover	Defender 90	D300 X Dyn HSE COMM	Carpathian	10000	2024	2024-01-31 00:00:00	SALEACAW8R2300435	2025-02-28 00:00:00	0.00	0.00	0.00	0.00	55000.00	11000.00	66000.00	2025-07-06 23:00:00	60000.00	0.00	0.00	0.00	12000.00	0.00	72000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1568.00	550.00	0.00	\N	\N	\N	Parkmore	Roofing Contractors	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
192	AL253974	AL	MS	Stock	On Site	RV23 XDP	Land Rover	Sport	ABIO P440e Hybrid	Borasco	28500	2023	2023-03-08 00:00:00	SAL1A2A44PA124932	2025-03-20 00:00:00	0.00	0.00	0.00	68326.59	5673.41	0.00	74000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
193	AL253983	AL	MS	Stock	On Site	SV72 ZBR	Land Rover	Sport	D300 DYN-SE	Black	29500	2022	2022-10-09 23:00:00	SAL1A2AW3PA102115	2025-03-26 00:00:00	0.00	0.00	0.00	59127.22	4657.78	0.00	63785.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
195	AL253989	AL	MS	Stock	On Site	SN22 AAF	Lamborghini	Urus	V8 Auto	Black	17500	2022	2022-03-01 00:00:00	ZPBEA1ZL3NLA18061	2025-04-06 23:00:00	0.00	0.00	0.00	0.00	173500.00	0.00	173500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
196	AL253995	AL	MS	Stock	On Site	BV72 HSD	Land Rover	Defender 110	D250 X-DYN HSE	Black	23500	2025	2025-10-16 23:00:00	SALEA7AW3P2154658	2025-04-09 23:00:00	0.00	0.00	0.00	0.00	64491.00	0.00	64491.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
197	AL253997	AL	MS	Stock	On Site	RO22 EGJ	Land Rover	Defender 110	D250 SE MHEV	Black	40047	2022	2022-03-24 00:00:00	SALEA7AW7N2104049	2025-04-09 23:00:00	0.00	0.00	0.00	0.00	48524.99	0.00	48524.99	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
198	AL254000	AL	MS	Stock	On Site	BK25 KYS	Audi	Q7	TFSI 55 BLK EDT	Black	100	2025	2025-03-22 00:00:00	WAUZZZ4M9SD020691	2025-04-09 23:00:00	0.00	0.00	0.00	49782.50	12217.50	0.00	62000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
199	AL254002	AL	MS	Stock	On Site	RX74 ZKM	Land Rover	Defender 110	D350 X-DYN HSE	Black	6200	2024	2024-09-19 23:00:00	SALEA7AW6S2373686	2025-04-10 23:00:00	0.00	0.00	0.00	63125.57	7874.43	0.00	71000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
201	AL254010	AL	MS	Stock	On Site	KR24 WGK	Land Rover	Sport	DYN-SE P460e	White	7200	2024	2024-07-22 23:00:00	SAL1A2A41RA408358	2025-04-15 23:00:00	0.00	0.00	0.00	71320.05	1780.95	0.00	73101.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
202	AL254012	AL	MS	Stock	On Site	FY21 WOV	Audi	SQ7	Black Edtion	Black	24500	2021	2021-04-05 23:00:00	WAUZZZ4M6MD024121	2025-04-16 23:00:00	0.00	0.00	0.00	0.00	48250.00	0.00	48250.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
203	AL254017	AL	MS	Sold	On Site	PJ23 DWO	Land Rover	Defender 110	D300 X-DYN HSE	Black	19812	2023	2023-04-04 23:00:00	SALEA7AW0P2207557	2025-04-25 23:00:00	0.00	0.00	0.00	0.00	54000.00	10800.00	64800.00	2025-07-06 23:00:00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
204	AL254018	AL	MS	Stock	On Site	OV71 HCK	Toyota	Landcruiser	Invincible 2.8D	Blue	29140	2021	2021-12-17 00:00:00	JTEBR3FJX0K227597	2025-04-28 23:00:00	0.00	0.00	0.00	0.00	47066.00	0.00	47066.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
186	AL243885	AL	ZH	Stock	On Site	KF18 HWZ	Land Rover	Discovery	HSE 3.0D	Black	65100	2018	2018-03-21 00:00:00	SALRA2AKXHA044182	2024-12-04 00:00:00	0.00	0.00	0.00	0.00	21000.00	0.00	21000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
205	AL254020	AL	MS	Stock	On Site	KS22 TYP	Land Rover	Defender 110	XS EDT P400e	Black	37200	2022	2022-07-03 23:00:00	SALEA7AY4P2132105	2025-04-25 23:00:00	0.00	0.00	0.00	0.00	56500.00	0.00	56500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
207	AL254027	AL	MS	Stock	On Site	YP72 XZY	Land Rover	Defender 110	X-DYN HSE P400e	Black	36500	2022	2022-11-08 00:00:00	SALEA7AY9P2160448	2025-04-30 23:00:00	0.00	0.00	0.00	0.00	54500.00	0.00	54500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
208	AL254028	AL	MS	Stock	On Site	SW73 CWO	Land Rover	Defender 110	D250 HSE MHEV	Black	6350	2023	2023-12-22 00:00:00	SALEA7AW5R2279468	2025-04-30 23:00:00	0.00	0.00	0.00	0.00	61000.00	0.00	61000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
209	AL254030	AL	MS	Stock	On Site	HK72 ULB	Porsche	Taycan	Performance+ 93.4kWh	Black	23038	2022	2022-12-22 00:00:00	WP0ZZZY14PSA30084	2025-05-02 23:00:00	0.00	0.00	0.00	0.00	40000.00	8000.00	48000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
210	AL254031	AL	MS	Stock	On Site	MT23 VNC	Land Rover	Sport	D300 DYN-SE	White	28000	2023	2023-06-15 23:00:00	SAL1A2AW9PA139945	2025-05-05 23:00:00	0.00	0.00	0.00	0.00	64800.00	0.00	64800.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
190	AL253960	AL	MS	Sold	On Site	LB22 UCP	Land Rover	Defender 110	V8 P525	Black	17000	2021	2021-06-29 23:00:00	SALEA7AE7P2134520	2025-03-09 00:00:00	0.00	0.00	0.00	0.00	77000.00	0.00	77000.00	2025-07-03 23:00:00	1000.00	81875.00	0.00	0.00	0.00	0.00	82875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	2171.52	350.00	428.00	\N	\N	\N	William	Darlington	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
211	AL254033	AL	PX	Stock	On Site	YL23 OBT (2)	Land Rover	Sport	ABIO P440e	Carpathian	15000	2023	2023-08-24 23:00:00	SAL1A2A47PA152711	2025-05-06 23:00:00	5091.83	0.00	0.00	71908.17	0.00	0.00	77000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
213	AL254035	MSR	ZR	Stock	On Site	RY23 KJJ	BMW	3 Series	320I M Sport Estate	Grey	18536	2023	2023-03-07 00:00:00	WBA22FY070FP49737	2025-05-06 23:00:00	0.00	0.00	0.00	0.00	28466.40	0.00	28466.40	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
206	AL254024	AL	MS	Sold	On Site	MH22 HLG	Land Rover	Vogue	D300 SE MHEV	Eiger	21400	2022	2022-04-25 23:00:00	SALKA9AW9NA005544	2025-04-27 23:00:00	0.00	0.00	0.00	0.00	70000.00	0.00	70000.00	2025-06-24 23:00:00	20000.00	58000.00	0.00	0.00	0.00	0.00	78000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1945.00	450.00	428.00	\N	\N	\N	Raymond	Jones	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
200	AL254005	AL	MS	Sold	On Site	VA22 NUB	Land Rover	Sport	D300 DYN-SE	Carpathian	25500	2022	2022-07-12 23:00:00	SAL1A2AW3PA100347	2025-04-13 23:00:00	0.00	500.00	0.00	0.00	62750.00	0.00	63250.00	2025-06-26 23:00:00	52500.00	0.00	0.00	0.00	0.00	7000.00	59500.00	8000.00	0.00	0.00	0.00	0.00	0.00	0.00	1368.65	300.00	428.00	\N	\N	\N	Hunters	Construction Ltd	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
188	AL253948	AL	PX	Stock	On Site	EF14 DME	Mercedes	C Class	C220 AMG Prem +	White	81000	2014	2014-03-01 00:00:00	WDD2040022A933955	2025-02-23 00:00:00	9000.00	0.00	0.00	0.00	0.00	0.00	9000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	Real PX Price 5k	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
212	AL254034	MSR	ZR	Sold	On Site	RK18 YRE	BMW	7 Series	M760Li M Sport	Black	62740	2018	2018-03-01 00:00:00	WBA7H62070BL02278	2025-05-06 23:00:00	0.00	0.00	0.00	0.00	31077.40	0.00	31077.40	2025-07-01 23:00:00	31077.40	0.00	0.00	0.00	0.00	0.00	31077.40	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	MSR	Prestige	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
191	AL253962	AL	MS	Stock	On Site	YW23 CYF	Land Rover	Defender 110	Hard Top COMM	Eiger	32516	2023	2023-06-29 23:00:00	SALEAJAW0P2214604	2025-03-12 00:00:00	0.00	0.00	0.00	0.00	45583.33	9116.67	54700.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
234	AL254069	MSR	PX	Stock	On Site	WX22 WMU	Mercedes	GLC300e	AMG Line 4 Matic	Black	35000	2022	2022-03-30 23:00:00	W1N2539532G049235	2025-06-16 23:00:00	24000.00	0.00	0.00	0.00	0.00	0.00	24000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
216	AL254040	AL	MS	Stock	On Site	YE72 NHU	Land Rover	Sport	P440e DYN-SE PHEV	White	42298	2022	2022-11-08 00:00:00	SAL1A2A44PA108004	2025-05-10 23:00:00	0.00	0.00	0.00	0.00	59647.00	0.00	59647.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
237	AL254072	AL	PX	Stock	On Site	ML22 WHN (2)	Land Rover	Defender 110	D250 XS EDT	Black	40000	2022	2022-04-27 23:00:00	SALEA7AW7P2118679	2025-06-17 23:00:00	49000.00	0.00	0.00	0.00	0.00	0.00	49000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
220	AL254048	AL	ZH	Stock	On Site	BW69 SJY	Mercedes	GLC	63s Premium Plus	White	55700	2019	2019-12-13 00:00:00	WDC2539892F748231	2025-05-18 23:00:00	0.00	0.00	0.00	37480.28	1900.00	0.00	39380.28	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
221	AL254050	MSR	ZR	Sold	On Site	RA68 ZSG	Audi	S4	TFSI Quattro	White	36951	2018	2019-01-26 00:00:00	WAUZZZF45JA191869	2025-05-21 23:00:00	0.00	0.00	0.00	17057.88	1842.12	0.00	18900.00	2025-07-06 23:00:00	19367.00	0.00	0.00	0.00	0.00	0.00	19367.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	MSR	Prestige	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
222	AL254051	MSR	ZR	Stock	On Site	VN20 TYG	Audi	A4	S Line 30 TDI	Blue	61000	2020	2020-07-29 23:00:00	WAUZZZF47LA012279	2025-05-22 23:00:00	-1253.38	0.00	0.00	17903.38	0.00	0.00	16650.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
223	AL254052	MSR	ZR	Stock	On Site	PO17 XZG	Mercedes	AMG GLC	43 4 Matic Prem +	White	86000	2017	2017-03-09 00:00:00	WDC2539642F237538	2025-05-23 23:00:00	0.00	0.00	0.00	0.00	16900.00	0.00	16900.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
224	AL254053	MSR	PX	Stock	On Site	LV20 FZS	Audi	A3	S Line 35 TFSI	Grey	38000	2020	2020-08-04 23:00:00	WAUZZZGY6MA015712	2025-05-27 23:00:00	16250.00	0.00	0.00	0.00	0.00	0.00	16250.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
225	AL254057	MSR	PX	Stock	On Site	KR67 RXG	Mercedes	GLC 250 D	AMG Line Premium	Black	55600	2018	2018-01-31 00:00:00	WDC2539092V064008	2025-05-29 23:00:00	16270.00	0.00	0.00	0.00	0.00	0.00	16270.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
226	AL254058	MSR	ZR	Stock	On Site	CK19 YWB	Mercedes	AMG GLC	45 Premium 4Matic	Black	51470	2019	2019-03-30 00:00:00	WDC2533642F629103	2025-05-29 23:00:00	0.00	0.00	0.00	0.00	21000.00	0.00	21000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
227	AL254060	MSR	ZR	Stock	On Site	LN68 MWM	BMW	2 Series	M240i	White	44200	2018	2019-09-07 23:00:00	WBA2J52050VD72730	2025-05-30 23:00:00	0.00	0.00	0.00	0.00	15000.00	0.00	15000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
228	AL254061	AL	MS	Stock	On Site	DA72 ZHH	Volkswagen	Tiguan	R Line	White	30664	2022	2023-01-03 00:00:00	WVGZZZ5N9PW030008	2025-06-01 23:00:00	0.00	500.00	0.00	0.00	24500.00	0.00	25000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:45:02.095
229	AL254063	AL	ZH	Stock	On Site	DE72 USV	Audi	A8	Black Edition TFSI 55	Blue	30936	2022	2022-09-26 23:00:00	WAUZZZF83NN009331	2025-06-01 23:00:00	0.00	0.00	0.00	0.00	33555.00	0.00	33555.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565	2025-06-26 08:46:39.315
230	AL254064	MSR	ZR	Sold	On Site	PG18 HTK	BMW	X5	M Sport Auto	Black	60752	2018	2018-06-28 23:00:00	WBSTK620600E73784	2025-06-01 23:00:00	0.00	0.00	0.00	0.00	26042.00	0.00	26042.00	2025-07-06 23:00:00	26042.00	0.00	0.00	0.00	0.00	0.00	26042.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	MSR	Prestige	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
231	AL254065	MSR	ZR	Stock	On Site	SC21 AOX	BMW	320D	X Drive MHT	Black	53795	2021	2021-07-29 23:00:00	WBA32DY090FL63605	2025-06-01 23:00:00	0.00	0.00	0.00	0.00	18928.00	0.00	18928.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565	2025-06-26 08:46:55.051
232	AL254066	AL	MS	Stock	On Site	FY09 LRO	Honda	Civic	ES I Vtec	Silver	145000	2009	2009-03-18 00:00:00	SHHFK27608U042814	2025-06-04 23:00:00	0.00	0.00	0.00	0.00	2000.00	0.00	2000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
235	AL254070	AL	FA	Stock	On Site	BV72 GJX	Porsche	Taycan	Turbo S Sport Turismo	White	22000	2022	2022-10-27 23:00:00	WP0ZZZY15PSA86051	2025-06-16 23:00:00	-28607.54	0.00	0.00	89829.54	0.00	0.00	61222.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
238	AL254073	AL	PX	Sold	On Site	SJ68 OEN (2)	Land Rover	Sport	HSE Dyn SDV6	Black	60000	2018	2018-09-03 23:00:00	SALWA2AK5KA814248	2025-06-19 23:00:00	24000.00	0.00	0.00	0.00	0.00	0.00	24000.00	2025-07-07 23:00:00	24000.00	0.00	0.00	0.00	0.00	0.00	24000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	MSR	Prestige	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
239	AL254074	AL	ZR	Stock	On Site	OY64 OKS	Audi	S3	2.0 TFSI Sportback	Black	84745	2014	2014-09-14 23:00:00	WAUZZZ8V8FA024810	2025-06-22 23:00:00	0.00	0.00	0.00	8466.69	2733.31	0.00	11200.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
218	AL254046	AL	MS	Stock	On Site	YY73 SWF	Land Rover	Defender 110	D250 X-DYN HSE	Eiger Grey	10070	2023	2023-12-06 00:00:00	SALEA7AW2R2278553	2025-05-16 23:00:00	0.00	0.00	0.00	0.00	60000.00	0.00	60000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
240	AL254075	AL	MS	Stock	On Site	DN23 TYB	Land Rover	Sport	Dynamic SE D300	Black	18000	2023	2023-06-01 23:00:00	SAL1A2AW7PA135747	2025-06-22 23:00:00	0.00	500.00	0.00	0.00	63500.00	0.00	64000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
241	AL254076	AL	MS	Stock	On Site	YL71 JPV	Land Rover	Velar	D300 DYN-SE	Eiger	18800	2021	2021-10-29 23:00:00	SALYA2AW0MA325237	2025-06-23 23:00:00	0.00	0.00	0.00	0.00	31000.00	0.00	31000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
28	AL253911	AL	MS	Sold	On Site	PO23 YWB (2)	Land Rover	Defender 110	XS EDTION P400e	Black	13000	2023	2023-03-09 00:00:00	SALEA7AY4P2189176	2025-01-13 00:00:00	0.00	0.00	0.00	52358.29	11641.71	0.00	64000.00	2025-01-27 00:00:00	45000.00	0.00	0.00	26670.00	0.00	0.00	71670.00	0.00	0.00	590.00	80.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Christina	Hull	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
54	AL253902	AL	MS	Sold	On Site	BK23 PZV	Land Rover	Defender 110	D250 X-DYN HSE	Black	23500	2023	2023-03-01 00:00:00	SALEA7AW7P2180597	2025-01-07 00:00:00	0.00	0.00	0.00	0.00	65000.00	0.00	65000.00	2025-02-23 00:00:00	2000.00	49875.00	0.00	9000.00	0.00	9000.00	69875.00	9000.00	3000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Mandeep	Thandi	2025-06-26 08:09:24.223961	2025-06-26 08:09:24.223961
236	AL254071	AL	MS	Sold	On Site	JSZ 3542	Land Rover	Defender 110	D350 X-DYN HSE	Black	350	2025	2025-06-15 23:00:00	SALEA7AW1S2437147	2025-06-17 23:00:00	0.00	0.00	0.00	0.00	81500.00	0.00	81500.00	2025-06-21 23:00:00	0.00	45000.00	0.00	50000.00	0.00	0.00	95000.00	0.00	0.00	0.00	0.00	80.00	0.00	0.00	2956.00	300.00	0.00	\N	\N	\N	Gabriella	Henderson	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
217	AL254043	AL	MS	Sold	On Site	LN22 JKX (2)	Mercedes	G Wagon	400D AMG Line Prem+	Black	29000	2022	2022-03-16 00:00:00	W1N4633502X429981	2025-05-11 23:00:00	-244.06	0.00	0.00	101244.06	0.00	0.00	101000.00	2025-07-03 23:00:00	10000.00	60000.00	0.00	27000.00	0.00	4500.00	101500.00	7000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	250.00	332.00	\N	\N	PX O/R by 3k + 7k Cash O/B	Sajid	Mansha	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
219	AL254047	MSR	PX	Stock	On Site	YJ65 JKD	BMW	320D	M Sport	White	85000	2015	2015-09-28 23:00:00	WBA3D32020K558711	2025-05-17 23:00:00	-2627.91	0.00	0.00	9127.91	0.00	0.00	6500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
194	AL253986	AL	MS	Stock	On Site	KE23 WTM	Mercedes	G Wagon	AMG G63 V8	Black	18000	2023	2023-08-01 23:00:00	W1NYC7GJ7PX478363	2025-03-30 00:00:00	0.00	0.00	0.00	113704.07	7100.00	24166.67	144970.74	\N	145000.00	0.00	0.00	0.00	0.00	0.00	145000.00	17000.00	0.00	0.00	0.00	0.00	0.00	0.00	3600.00	350.00	0.00	\N	\N	\N	Ian	Morrison	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
214	AL254036	MSR	ZR	Stock	On Site	DS68 KTP	Land Rover	Range Rover	ABIO TDV6	White	36769	2018	2018-10-29 00:00:00	SALGA2AK1JA398167	2025-05-06 23:00:00	0.00	0.00	0.00	0.00	34699.40	0.00	34699.40	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
215	AL254039	AL	MS	Stock	On Site	SN66 BXJ	Lamborghini	Huracan	V10 LP 610-4 AVIO	Blue	36000	2016	2016-12-03 00:00:00	ZHWEC1ZF9HLA06510	2025-05-07 23:00:00	0.00	2000.00	0.00	75066.80	27433.20	0.00	104500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
244	AL254077	AL	ZR	Stock	On Site	SV19 BPP	Land Rover	Sport	HSE Dyn SDV6	Grey	66500	2019	2019-07-28 23:00:00	SALWA2AKXKA853711	2025-06-24 23:00:00	0.00	0.00	0.00	0.00	22500.00	0.00	22500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-07-03 08:02:07.665244	2025-07-03 08:02:07.665244
245	AL254079	AL	MS	Stock	On Site	AE25 SWX	Land Rover	Defender 110	D250 X-DYN HSE	Black	150	2025	2025-06-30 23:00:00	SALEA7AW6S2465686	2025-06-29 23:00:00	0.00	0.00	0.00	0.00	74000.00	0.00	74000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-07-03 08:02:07.757733	2025-07-03 08:02:07.757733
246	AL254080	MSR	ZR	Stock	On Site	R80 OXR	Audi	R8	5.2 V10 Spider	White	46000	2010	2010-05-16 23:00:00	WUAZZZ420AN002206	2025-07-01 23:00:00	0.00	0.00	0.00	0.00	40782.00	0.00	40782.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-07-03 08:02:07.850268	2025-07-03 08:02:07.850268
247	AL254081	MSR	ZR	Stock	On Site	ST19 DSX	BMW	X7	M50D M Sport	Black	112500	2019	2019-07-30 23:00:00	WBACW02080LB41700	2025-07-01 23:00:00	0.00	0.00	0.00	0.00	33978.00	0.00	33978.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-07-03 08:02:07.943023	2025-07-03 08:02:07.943023
106	AL253965	AL	MS	Sold	On Site	CA24 VGT	Land Rover	Vogue	ABIO P460e	Eiger	6000	2024	2024-04-16 23:00:00	SALKA9A46RA222912	2025-03-13 00:00:00	0.00	0.00	0.00	0.00	84166.67	16833.33	101000.00	2025-04-05 23:00:00	35854.17	59875.00	0.00	0.00	19145.83	0.00	114875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	590.00	450.00	0.00	\N	\N	Settlement Figure was 115356.04 (Negative EQ)	Hannah	Durose	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
131	AL254025	AL	MS	Sold	On Site	NX15 JKO	Land Rover	Discovery	Sport  HSE	White	66000	2015	2015-03-12 00:00:00	SALCA2AE9FH513735	2025-04-27 23:00:00	9600.00	0.00	0.00	0.00	0.00	0.00	9600.00	2025-05-02 23:00:00	10000.00	0.00	0.00	0.00	0.00	0.00	10000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	JDT	Motors	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
132	AL254003	AL	MS	Sold	On Site	OU21 YCJ	Land Rover	Defender 110	D250 SE MHEV	Eiger	48000	2021	2021-06-06 23:00:00	SALEA7AW0N2062792	2025-04-11 23:00:00	0.00	0.00	0.00	49000.00	-5000.00	0.00	44000.00	2025-05-02 23:00:00	40000.00	11000.00	0.00	0.00	0.00	0.00	51000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1195.00	300.00	427.84	\N	\N	\N	Charlene	Perkins	2025-06-26 08:09:24.448601	2025-06-26 08:09:24.448601
156	AL222972	AL	MS	Sold	On Site	BG21 XWR (2)	Audi	RS6 Avant	Vorsprung TFSI	Purple	8000	2021	2021-07-01 23:00:00	WUAZZZF24MN909767	2022-06-10 23:00:00	0.00	0.00	0.00	100000.00	0.00	0.00	100000.00	2025-06-02 23:00:00	30300.00	50000.00	0.00	0.00	0.00	0.00	80300.00	4000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	Asif	Surgeon	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
66	AL253957	AL	MS	Sold	On Site	KW23 ZRC	Land Rover	Defender 110	D250 X-DYN HSE 7 STR	Black	16500	2023	2023-06-05 23:00:00	SALEA7AW4P2220151	2025-03-03 00:00:00	0.00	0.00	0.00	0.00	64550.00	0.00	64550.00	2025-03-03 00:00:00	16500.00	53875.00	0.00	0.00	0.00	0.00	70375.00	9500.00	0.00	0.00	0.00	0.00	0.00	0.00	7327.00	550.00	0.00	\N	\N	\N	Surinder	Balsi	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
80	AL253953	AL	FA	Sold	On Site	CU25 SDZ	Volkswagen	Amarok	Dcab PanAmerica V6	Grey	293	2025	2025-03-01 00:00:00	WV4ZZZT1XR5027416	2025-03-03 00:00:00	0.00	0.00	0.00	0.00	43000.00	8600.00	51600.00	2025-03-14 00:00:00	35833.33	0.00	0.00	20000.00	11166.67	0.00	67000.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	4656.73	350.00	0.00	\N	\N	\N	Ben	Cooper	2025-06-26 08:09:24.34709	2025-06-26 08:09:24.34709
243	AL254078	AL	MS	Sold	On Site	HN24 MLF	Land Rover	Discovery	D300 DYN HSE	Carpathian	10550	2024	2024-04-16 23:00:00	SALRA2AW1R2495080	2025-06-26 23:00:00	0.00	0.00	0.00	0.00	55750.00	0.00	55750.00	2025-06-26 23:00:00	63390.00	0.00	0.00	0.00	0.00	0.00	63390.00	0.00	0.00	620.00	0.00	0.00	0.00	0.00	600.00	300.00	856.00	\N	\N	\N	David	Caunce	2025-07-03 08:02:01.281435	2025-07-03 08:02:01.281435
233	AL254068	AL	MS	Sold	On Site	SC22 WLZ	Porsche	Cayenne	V6 Platinum Edition	Black	22351	2022	2022-08-25 23:00:00	WP1ZZZ9YZNDA44695	2025-06-11 23:00:00	-968.04	0.00	0.00	54718.04	0.00	0.00	53750.00	2025-07-06 23:00:00	5000.00	56875.00	0.00	0.00	0.00	0.00	61875.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	420.00	350.00	332.00	\N	\N	\N	Taylan	Karagoz	2025-06-26 08:09:24.565287	2025-06-26 08:09:24.565287
184	AL243789	AL	SH	Stock	On Site	YG17 KXU	Mercedes	V Class	V250 D Sport Auto	Black	112300	2017	2017-05-08 23:00:00	WDF44781323287900	2024-08-18 23:00:00	0.00	0.00	0.00	0.00	23666.00	0.00	23666.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
187	AL253914	AL	MS	Stock	On Site	FX22 PXU	Land Rover	Defender 110	D250 X-DTN HSE MHEV	Black	17000	2022	2022-04-06 23:00:00	SALEA7AWXP2116554	2025-01-15 00:00:00	0.00	0.00	0.00	0.00	60500.00	0.00	60500.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-06-26 08:09:24.50848	2025-06-26 08:09:24.50848
248	AL254082	AL	PX	Stock	On Site	KM19 NOA	Land Rover	Sport	HSE DYN	Black	42500	2019	2019-08-01 23:00:00	SALWA2AK1KA875080	2025-07-02 23:00:00	27000.00	0.00	0.00	0.00	0.00	0.00	27000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-07-03 08:02:08.034841	2025-07-03 08:02:08.034841
249	AL254083	AL	MS	Stock	On Site	YK23 VCM	Land Rover	Sport	P510e First Edition PHEV	Black	23500	2023	2023-03-18 00:00:00	SAL1A2A44PA122355	2025-07-03 23:00:00	0.00	0.00	0.00	73387.91	1250.00	0.00	74637.91	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-07-08 14:35:03.052983	2025-07-08 14:35:03.052983
250	AL254084	AL	MS	Stock	On Site	WR24 DXW	Land Rover	Defender 110	P525 V8	Black	16000	2024	2024-03-30 00:00:00	SALEA7AEXR2323097	2025-07-06 23:00:00	0.00	0.00	0.00	0.00	80000.00	0.00	80000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-07-08 14:35:03.168419	2025-07-08 14:35:03.168419
251	AL254085	AL	PX	Stock	AWD	LM20 XBG	Mercedes	A35	4Matic Prem+	Grey	29000	2020	2020-07-03 23:00:00	W1K1770512N175438	2025-07-06 23:00:00	27000.00	0.00	0.00	0.00	0.00	0.00	27000.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	Real PX Price 24k	\N	\N	2025-07-08 14:35:03.268111	2025-07-08 14:35:03.268111
252	AL254086	AL	MS	Stock	On Site	KW73 YEE	Land Rover	Defender 110	X-DYN HSE PHEV	Green	15350	2023	2023-11-29 00:00:00	SALEA7AY9R2277286	2025-07-07 23:00:00	0.00	0.00	0.00	0.00	59750.00	0.00	59750.00	\N	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	\N	\N	\N	\N	\N	2025-07-08 14:35:03.411031	2025-07-08 14:35:03.411031
\.


--
-- Name: appointments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.appointments_id_seq', 8, true);


--
-- Name: bought_vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.bought_vehicles_id_seq', 1, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.customers_id_seq', 3, true);


--
-- Name: interactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.interactions_id_seq', 14, true);


--
-- Name: job_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.job_progress_id_seq', 1, false);


--
-- Name: job_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.job_templates_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.jobs_id_seq', 11, true);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.leads_id_seq', 4, true);


--
-- Name: page_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.page_definitions_id_seq', 33, true);


--
-- Name: purchase_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.purchase_invoices_id_seq', 1, true);


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.purchases_id_seq', 1, false);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.sales_id_seq', 1, false);


--
-- Name: sales_invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.sales_invoices_id_seq', 1, true);


--
-- Name: staff_schedules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.staff_schedules_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.user_permissions_id_seq', 13, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: vehicle_logistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.vehicle_logistics_id_seq', 1, false);


--
-- Name: vehicle_makes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.vehicle_makes_id_seq', 1, false);


--
-- Name: vehicle_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.vehicle_models_id_seq', 1, false);


--
-- Name: vehicles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.vehicles_id_seq', 252, true);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: bought_vehicles bought_vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.bought_vehicles
    ADD CONSTRAINT bought_vehicles_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: interactions interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_pkey PRIMARY KEY (id);


--
-- Name: job_progress job_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.job_progress
    ADD CONSTRAINT job_progress_pkey PRIMARY KEY (id);


--
-- Name: job_templates job_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.job_templates
    ADD CONSTRAINT job_templates_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_job_number_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_job_number_unique UNIQUE (job_number);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: page_definitions page_definitions_page_key_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.page_definitions
    ADD CONSTRAINT page_definitions_page_key_unique UNIQUE (page_key);


--
-- Name: page_definitions page_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.page_definitions
    ADD CONSTRAINT page_definitions_pkey PRIMARY KEY (id);


--
-- Name: purchase_invoices purchase_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: sales_invoices sales_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: staff_schedules staff_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.staff_schedules
    ADD CONSTRAINT staff_schedules_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: vehicle_logistics vehicle_logistics_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_logistics
    ADD CONSTRAINT vehicle_logistics_pkey PRIMARY KEY (id);


--
-- Name: vehicle_makes vehicle_makes_name_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_makes
    ADD CONSTRAINT vehicle_makes_name_unique UNIQUE (name);


--
-- Name: vehicle_makes vehicle_makes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_makes
    ADD CONSTRAINT vehicle_makes_pkey PRIMARY KEY (id);


--
-- Name: vehicle_models vehicle_models_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_models
    ADD CONSTRAINT vehicle_models_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_stock_number_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_stock_number_unique UNIQUE (stock_number);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: idx_appointments_assigned_to; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_assigned_to ON public.appointments USING btree (assigned_to_id);


--
-- Name: idx_appointments_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_created_at ON public.appointments USING btree (created_at);


--
-- Name: idx_appointments_customer_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_customer_id ON public.appointments USING btree (customer_id);


--
-- Name: idx_appointments_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_date ON public.appointments USING btree (appointment_date);


--
-- Name: idx_appointments_date_assigned; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_date_assigned ON public.appointments USING btree (appointment_date, assigned_to_id);


--
-- Name: idx_appointments_date_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_date_status ON public.appointments USING btree (appointment_date, status);


--
-- Name: idx_appointments_lead_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_lead_id ON public.appointments USING btree (lead_id);


--
-- Name: idx_appointments_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_status ON public.appointments USING btree (status);


--
-- Name: idx_appointments_status_type; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_status_type ON public.appointments USING btree (status, appointment_type);


--
-- Name: idx_appointments_type; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_type ON public.appointments USING btree (appointment_type);


--
-- Name: idx_appointments_vehicle_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_appointments_vehicle_id ON public.appointments USING btree (vehicle_id);


--
-- Name: idx_customers_assigned_salesperson; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_assigned_salesperson ON public.customers USING btree (assigned_salesperson_id);


--
-- Name: idx_customers_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_created_at ON public.customers USING btree (created_at);


--
-- Name: idx_customers_credit_rating; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_credit_rating ON public.customers USING btree (credit_rating);


--
-- Name: idx_customers_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_email ON public.customers USING btree (email);


--
-- Name: idx_customers_finance_preference; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_finance_preference ON public.customers USING btree (finance_preference);


--
-- Name: idx_customers_last_contact; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_last_contact ON public.customers USING btree (last_contact_date);


--
-- Name: idx_customers_lead_source; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_lead_source ON public.customers USING btree (lead_source);


--
-- Name: idx_customers_mobile; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_mobile ON public.customers USING btree (mobile);


--
-- Name: idx_customers_name_search; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_name_search ON public.customers USING btree (first_name, last_name);


--
-- Name: idx_customers_next_followup; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_next_followup ON public.customers USING btree (next_follow_up_date);


--
-- Name: idx_customers_phone; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_phone ON public.customers USING btree (phone);


--
-- Name: idx_customers_postcode; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_postcode ON public.customers USING btree (postcode);


--
-- Name: idx_customers_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_status ON public.customers USING btree (customer_status);


--
-- Name: idx_customers_status_salesperson; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_status_salesperson ON public.customers USING btree (customer_status, assigned_salesperson_id);


--
-- Name: idx_customers_total_purchases; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_total_purchases ON public.customers USING btree (total_purchases);


--
-- Name: idx_customers_total_spent; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_total_spent ON public.customers USING btree (total_spent);


--
-- Name: idx_customers_updated_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_customers_updated_at ON public.customers USING btree (updated_at);


--
-- Name: idx_interactions_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_created_at ON public.interactions USING btree (created_at);


--
-- Name: idx_interactions_customer_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_customer_id ON public.interactions USING btree (customer_id);


--
-- Name: idx_interactions_customer_type; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_customer_type ON public.interactions USING btree (customer_id, interaction_type);


--
-- Name: idx_interactions_direction; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_direction ON public.interactions USING btree (interaction_direction);


--
-- Name: idx_interactions_followup_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_followup_date ON public.interactions USING btree (follow_up_date);


--
-- Name: idx_interactions_followup_priority; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_followup_priority ON public.interactions USING btree (follow_up_priority);


--
-- Name: idx_interactions_followup_required; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_followup_required ON public.interactions USING btree (follow_up_required);


--
-- Name: idx_interactions_lead_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_lead_id ON public.interactions USING btree (lead_id);


--
-- Name: idx_interactions_lead_type; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_lead_type ON public.interactions USING btree (lead_id, interaction_type);


--
-- Name: idx_interactions_outcome; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_outcome ON public.interactions USING btree (interaction_outcome);


--
-- Name: idx_interactions_type; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_type ON public.interactions USING btree (interaction_type);


--
-- Name: idx_interactions_type_outcome; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_type_outcome ON public.interactions USING btree (interaction_type, interaction_outcome);


--
-- Name: idx_interactions_user_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_user_date ON public.interactions USING btree (user_id, created_at);


--
-- Name: idx_interactions_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_user_id ON public.interactions USING btree (user_id);


--
-- Name: idx_interactions_vehicle_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_interactions_vehicle_id ON public.interactions USING btree (vehicle_id);


--
-- Name: idx_jobs_assigned_to; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_assigned_to ON public.jobs USING btree (assigned_to_id);


--
-- Name: idx_jobs_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_created_at ON public.jobs USING btree (created_at);


--
-- Name: idx_jobs_customer_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_customer_id ON public.jobs USING btree (customer_id);


--
-- Name: idx_jobs_job_priority; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_job_priority ON public.jobs USING btree (job_priority);


--
-- Name: idx_jobs_job_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_job_status ON public.jobs USING btree (job_status);


--
-- Name: idx_jobs_job_type; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_job_type ON public.jobs USING btree (job_type);


--
-- Name: idx_jobs_scheduled_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_scheduled_date ON public.jobs USING btree (scheduled_date);


--
-- Name: idx_jobs_vehicle_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_jobs_vehicle_id ON public.jobs USING btree (vehicle_id);


--
-- Name: idx_leads_assigned_salesperson; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_assigned_salesperson ON public.leads USING btree (assigned_salesperson_id);


--
-- Name: idx_leads_assigned_vehicle; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_assigned_vehicle ON public.leads USING btree (assigned_vehicle_id);


--
-- Name: idx_leads_contact_attempts; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_contact_attempts ON public.leads USING btree (contact_attempts);


--
-- Name: idx_leads_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_created_at ON public.leads USING btree (created_at);


--
-- Name: idx_leads_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_email ON public.leads USING btree (email);


--
-- Name: idx_leads_last_contact; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_last_contact ON public.leads USING btree (last_contact_date);


--
-- Name: idx_leads_lead_quality; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_lead_quality ON public.leads USING btree (lead_quality);


--
-- Name: idx_leads_lead_source; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_lead_source ON public.leads USING btree (lead_source);


--
-- Name: idx_leads_next_followup; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_next_followup ON public.leads USING btree (next_follow_up_date);


--
-- Name: idx_leads_pipeline_stage; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_pipeline_stage ON public.leads USING btree (pipeline_stage);


--
-- Name: idx_leads_primary_phone; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_primary_phone ON public.leads USING btree (primary_phone);


--
-- Name: idx_leads_priority; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_priority ON public.leads USING btree (priority);


--
-- Name: idx_leads_updated_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_leads_updated_at ON public.leads USING btree (updated_at);


--
-- Name: idx_sales_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_created_at ON public.sales USING btree (created_at);


--
-- Name: idx_sales_customer_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_customer_id ON public.sales USING btree (customer_id);


--
-- Name: idx_sales_date_price; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_date_price ON public.sales USING btree (sale_date, sale_price);


--
-- Name: idx_sales_date_salesperson; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_date_salesperson ON public.sales USING btree (sale_date, salesperson_id);


--
-- Name: idx_sales_finance_provider; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_finance_provider ON public.sales USING btree (finance_provider);


--
-- Name: idx_sales_gross_profit; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_gross_profit ON public.sales USING btree (gross_profit);


--
-- Name: idx_sales_sale_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_sale_date ON public.sales USING btree (sale_date);


--
-- Name: idx_sales_sale_price; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_sale_price ON public.sales USING btree (sale_price);


--
-- Name: idx_sales_salesperson_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_salesperson_date ON public.sales USING btree (salesperson_id, sale_date);


--
-- Name: idx_sales_salesperson_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_salesperson_id ON public.sales USING btree (salesperson_id);


--
-- Name: idx_sales_vehicle_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_sales_vehicle_id ON public.sales USING btree (vehicle_id);


--
-- Name: idx_user_permissions_page_key; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_user_permissions_page_key ON public.user_permissions USING btree (page_key);


--
-- Name: idx_user_permissions_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_user_permissions_user_id ON public.user_permissions USING btree (user_id);


--
-- Name: idx_users_active_role; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_active_role ON public.users USING btree (is_active, role);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: idx_users_last_login; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_last_login ON public.users USING btree (last_login);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_role_name; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_role_name ON public.users USING btree (role, first_name, last_name);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_vehicles_collection_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_collection_status ON public.vehicles USING btree (collection_status);


--
-- Name: idx_vehicles_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_created_at ON public.vehicles USING btree (created_at);


--
-- Name: idx_vehicles_customer_name; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_customer_name ON public.vehicles USING btree (customer_first_name, customer_surname);


--
-- Name: idx_vehicles_department; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_department ON public.vehicles USING btree (department);


--
-- Name: idx_vehicles_make; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_make ON public.vehicles USING btree (make);


--
-- Name: idx_vehicles_make_model; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_make_model ON public.vehicles USING btree (make, model);


--
-- Name: idx_vehicles_make_year; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_make_year ON public.vehicles USING btree (make, year);


--
-- Name: idx_vehicles_mileage; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_mileage ON public.vehicles USING btree (mileage);


--
-- Name: idx_vehicles_model; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_model ON public.vehicles USING btree (model);


--
-- Name: idx_vehicles_purchase_date_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_purchase_date_status ON public.vehicles USING btree (purchase_invoice_date, sales_status);


--
-- Name: idx_vehicles_purchase_invoice_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_purchase_invoice_date ON public.vehicles USING btree (purchase_invoice_date);


--
-- Name: idx_vehicles_registration; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_registration ON public.vehicles USING btree (registration);


--
-- Name: idx_vehicles_sale_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_sale_date ON public.vehicles USING btree (sale_date);


--
-- Name: idx_vehicles_sale_date_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_sale_date_status ON public.vehicles USING btree (sale_date, sales_status);


--
-- Name: idx_vehicles_sales_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_sales_status ON public.vehicles USING btree (sales_status);


--
-- Name: idx_vehicles_status_date; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_status_date ON public.vehicles USING btree (sales_status, sale_date);


--
-- Name: idx_vehicles_status_make; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_status_make ON public.vehicles USING btree (sales_status, make);


--
-- Name: idx_vehicles_status_stock; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_status_stock ON public.vehicles USING btree (sales_status, stock_number);


--
-- Name: idx_vehicles_updated_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_updated_at ON public.vehicles USING btree (updated_at);


--
-- Name: idx_vehicles_year; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_vehicles_year ON public.vehicles USING btree (year);


--
-- Name: appointments appointments_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id);


--
-- Name: appointments appointments_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: appointments appointments_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id);


--
-- Name: appointments appointments_vehicle_id_vehicles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_vehicle_id_vehicles_id_fk FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: customers customers_assigned_salesperson_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_assigned_salesperson_id_users_id_fk FOREIGN KEY (assigned_salesperson_id) REFERENCES public.users(id);


--
-- Name: interactions interactions_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: interactions interactions_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id);


--
-- Name: interactions interactions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: interactions interactions_vehicle_id_vehicles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_vehicle_id_vehicles_id_fk FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: job_progress job_progress_job_id_jobs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.job_progress
    ADD CONSTRAINT job_progress_job_id_jobs_id_fk FOREIGN KEY (job_id) REFERENCES public.jobs(id);


--
-- Name: job_progress job_progress_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.job_progress
    ADD CONSTRAINT job_progress_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: job_templates job_templates_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.job_templates
    ADD CONSTRAINT job_templates_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: jobs jobs_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id);


--
-- Name: jobs jobs_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: jobs jobs_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: jobs jobs_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id);


--
-- Name: jobs jobs_parent_job_id_jobs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_parent_job_id_jobs_id_fk FOREIGN KEY (parent_job_id) REFERENCES public.jobs(id);


--
-- Name: jobs jobs_quality_check_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_quality_check_by_id_users_id_fk FOREIGN KEY (quality_check_by_id) REFERENCES public.users(id);


--
-- Name: jobs jobs_supervisor_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_supervisor_id_users_id_fk FOREIGN KEY (supervisor_id) REFERENCES public.users(id);


--
-- Name: jobs jobs_vehicle_id_vehicles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_vehicle_id_vehicles_id_fk FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: leads leads_assigned_salesperson_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_assigned_salesperson_id_users_id_fk FOREIGN KEY (assigned_salesperson_id) REFERENCES public.users(id);


--
-- Name: leads leads_assigned_vehicle_id_vehicles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_assigned_vehicle_id_vehicles_id_fk FOREIGN KEY (assigned_vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: leads leads_converted_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_converted_customer_id_customers_id_fk FOREIGN KEY (converted_customer_id) REFERENCES public.customers(id);


--
-- Name: purchases purchases_vehicle_id_vehicles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_vehicle_id_vehicles_id_fk FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: sales sales_customer_id_customers_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_customer_id_customers_id_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: sales sales_salesperson_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_salesperson_id_users_id_fk FOREIGN KEY (salesperson_id) REFERENCES public.users(id);


--
-- Name: sales sales_vehicle_id_vehicles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_vehicle_id_vehicles_id_fk FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: staff_schedules staff_schedules_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.staff_schedules
    ADD CONSTRAINT staff_schedules_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: staff_schedules staff_schedules_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.staff_schedules
    ADD CONSTRAINT staff_schedules_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_created_by_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_id_users_id_fk FOREIGN KEY (created_by_id) REFERENCES public.users(id);


--
-- Name: user_permissions user_permissions_page_key_page_definitions_page_key_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_page_key_page_definitions_page_key_fk FOREIGN KEY (page_key) REFERENCES public.page_definitions(page_key) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: vehicle_logistics vehicle_logistics_assigned_to_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_logistics
    ADD CONSTRAINT vehicle_logistics_assigned_to_id_users_id_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users(id);


--
-- Name: vehicle_logistics vehicle_logistics_vehicle_id_vehicles_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_logistics
    ADD CONSTRAINT vehicle_logistics_vehicle_id_vehicles_id_fk FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id);


--
-- Name: vehicle_models vehicle_models_make_id_vehicle_makes_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.vehicle_models
    ADD CONSTRAINT vehicle_models_make_id_vehicle_makes_id_fk FOREIGN KEY (make_id) REFERENCES public.vehicle_makes(id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

